# nmschooldata

[![R-CMD-check](https://github.com/almartin82/nmschooldata/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/almartin82/nmschooldata/actions/workflows/R-CMD-check.yaml)
[![Python Tests](https://github.com/almartin82/nmschooldata/actions/workflows/python-test.yaml/badge.svg)](https://github.com/almartin82/nmschooldata/actions/workflows/python-test.yaml)
[![pkgdown](https://github.com/almartin82/nmschooldata/actions/workflows/pkgdown.yaml/badge.svg)](https://github.com/almartin82/nmschooldata/actions/workflows/pkgdown.yaml)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)

Fetch and analyze New Mexico school enrollment data from the New Mexico Public Education Department (PED) in R or Python.

## What can you find with nmschooldata?

**10 years of enrollment data (2016-2025).** Around 330,000 students. 89 school districts.

See the [enrollment insights vignette](https://almartin82.github.io/nmschooldata/articles/enrollment_hooks.html) for code examples and analysis.

Note: Data availability varies by year. 2024 only has 80-Day data (40-Day subgroup file was not published). Demographic subgroup data is available for 2019-2023 and 2025 only.

---

## Installation

```r
# install.packages("remotes")
remotes::install_github("almartin82/state-schooldata", subdir = "nmschooldata")
```

## Quick start

### R

```r
library(nmschooldata)
library(dplyr)

# Fetch one year
enr_2023 <- fetch_enr(2023)

# Fetch multiple years
enr_multi <- fetch_enr_multi(2019:2023)

# State totals
enr_2023 %>%
  filter(is_state, subgroup == "total", grade_level == "TOTAL")

# District breakdown
enr_2023 %>%
  filter(is_district, subgroup == "total", grade_level == "TOTAL") %>%
  arrange(desc(n_students))

# Demographics statewide
enr_2023 %>%
  filter(is_state, grade_level == "TOTAL",
         subgroup %in% c("hispanic", "white", "native_american", "black", "asian")) %>%
  select(subgroup, n_students, pct)
```

### Python

```python
import pynmschooldata as nm

# Check available years
years = nm.get_available_years()
print(f"Data available: {years['min_year']}-{years['max_year']}")

# Fetch one year
enr_2023 = nm.fetch_enr(2023)

# Fetch multiple years
enr_multi = nm.fetch_enr_multi([2019, 2020, 2021, 2022, 2023])

# State totals
state_total = enr_2023[
    (enr_2023['is_state'] == True) &
    (enr_2023['subgroup'] == 'total') &
    (enr_2023['grade_level'] == 'TOTAL')
]

# District breakdown
districts = enr_2023[
    (enr_2023['is_district'] == True) &
    (enr_2023['subgroup'] == 'total') &
    (enr_2023['grade_level'] == 'TOTAL')
].sort_values('n_students', ascending=False)
```

## Data availability

| Years | Source | Aggregation Levels | Demographics | Grade Breakdown |
|-------|--------|-------------------|--------------|-----------------|
| **2025** | 40-Day subgroup | State, District, School | 13 subgroups | TOTAL only |
| **2024** | 80-Day only | State, District | None | PK through 12 |
| **2019-2023** | 40-Day subgroup | State, School | 13 subgroups | TOTAL only |
| **2016-2018** | 40-Day enrollment | State, District, School | None | PK through 12 |

### What's available by year range

- **Demographics**: 13 subgroups (race/ethnicity, gender, special populations) available for 2019-2023 and 2025. No demographics for 2016-2018 or 2024.
- **Grade Breakdown**: Individual grade counts (PK-12) available for 2016-2018 and 2024. Only TOTAL for 2019-2023 and 2025.
- **40-Day vs 80-Day**: New Mexico reports enrollment at 40-day and 80-day counts. This package uses 40-day data when available (the standard snapshot used for funding). **Note: 2024 only has 80-Day data** - the 40-Day subgroup file was never published by NM PED.

## Data source

New Mexico Public Education Department:
- [PED Main](https://webnew.ped.state.nm.us/)
- [STARS System](https://web.ped.nm.gov/bureaus/information-technology/stars/)
- [NM Vistas](https://nmvistas.org/)

## Part of the State Schooldata Project

A simple, consistent interface for accessing state-published school data in Python and R.

**All 50 state packages:** [github.com/almartin82](https://github.com/almartin82?tab=repositories&q=schooldata)

## Author

[Andy Martin](https://github.com/almartin82) (almartin@gmail.com)

## License

MIT
