# ==============================================================================
# Directory Data Tests for nmschooldata
# ==============================================================================
#
# These tests verify the fetch_directory() function and related helpers.
# Tests include LIVE network calls to verify actual data source availability.
#
# ==============================================================================

library(testthat)
library(httr)

# Skip if no network connectivity
skip_if_offline <- function() {
  tryCatch({
    response <- httr::HEAD("https://www.google.com", httr::timeout(5))
    if (httr::http_error(response)) {
      skip("No network connectivity")
    }
  }, error = function(e) {
    skip("No network connectivity")
  })
}

# ==============================================================================
# URL Availability Tests
# ==============================================================================

test_that("NM PED directory URLs return HTTP 200", {
  skip_if_offline()
  skip_on_cran()

  # Test each of the directory file URLs
  urls <- c(
    schools = "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-nm-schools.csv",
    principal_elem = "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-principal-elementary.csv",
    principal_mid = "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-principal-jr-mid-high.csv",
    principal_high = "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-principal-secondary.csv",
    superintendent = "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-superintendent.csv"
  )

  for (name in names(urls)) {
    response <- httr::HEAD(urls[[name]], httr::timeout(60))
    expect_equal(
      httr::status_code(response),
      200,
      label = paste(name, "file should return HTTP 200")
    )
  }
})

# ==============================================================================
# File Download Tests
# ==============================================================================

test_that("Can download directory CSV files", {
  skip_if_offline()
  skip_on_cran()

  # Test downloading the schools file
  url <- "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-nm-schools.csv"
  temp_file <- tempfile(fileext = ".csv")

  response <- httr::GET(
    url,
    httr::write_disk(temp_file, overwrite = TRUE),
    httr::timeout(120)
  )

  expect_equal(httr::status_code(response), 200)
  expect_gt(file.info(temp_file)$size, 1000,
            label = "File should not be empty")

  # Verify it's actually CSV text, not HTML error page
  file_type <- system(paste("file -b", shQuote(temp_file)), intern = TRUE)
  expect_false(grepl("HTML", file_type, ignore.case = TRUE),
               label = "File should not be HTML error page")

  unlink(temp_file)
})

# ==============================================================================
# File Parsing Tests
# ==============================================================================

test_that("Can parse directory CSV files with readr", {
  skip_if_offline()
  skip_on_cran()

  url <- "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-nm-schools.csv"
  temp_file <- tempfile(fileext = ".csv")

  httr::GET(
    url,
    httr::write_disk(temp_file, overwrite = TRUE),
    httr::timeout(120)
  )

  df <- readr::read_csv(
    temp_file,
    col_types = readr::cols(.default = readr::col_character()),
    show_col_types = FALSE
  )

  expect_true(is.data.frame(df))
  expect_gt(nrow(df), 0, label = "CSV should have data rows")
  expect_gt(ncol(df), 0, label = "CSV should have columns")

  unlink(temp_file)
})

# ==============================================================================
# Column Structure Tests
# ==============================================================================

test_that("Schools CSV has expected columns", {
  skip_if_offline()
  skip_on_cran()

  url <- "https://web.ped.nm.gov/wp-content/uploads/2025/01/09-2024-nmpsd-nm-schools.csv"
  temp_file <- tempfile(fileext = ".csv")

  httr::GET(
    url,
    httr::write_disk(temp_file, overwrite = TRUE),
    httr::timeout(120)
  )

  df <- readr::read_csv(
    temp_file,
    col_types = readr::cols(.default = readr::col_character()),
    show_col_types = FALSE
  )

  col_names_lower <- tolower(names(df))

  # Key columns that should exist
  expect_true(any(grepl("district", col_names_lower)),
              label = "Should have district column")
  expect_true(any(grepl("school", col_names_lower)),
              label = "Should have school column")
  expect_true(any(grepl("address", col_names_lower)),
              label = "Should have address column")

  unlink(temp_file)
})

# ==============================================================================
# get_raw_directory() Function Tests
# ==============================================================================

test_that("get_raw_directory downloads and merges all files", {
  skip_if_offline()
  skip_on_cran()

  raw <- nmschooldata:::get_raw_directory()

  expect_true(is.data.frame(raw))
  expect_gt(nrow(raw), 0, label = "Should have school records")

  # Check that principals and superintendents are attached as attributes
  principals <- attr(raw, "principals")
  superintendents <- attr(raw, "superintendents")

  expect_true(is.data.frame(principals) || is.null(principals))
  expect_true(is.data.frame(superintendents) || is.null(superintendents))

  if (!is.null(principals)) {
    expect_gt(nrow(principals), 0, label = "Should have principal records")
  }

  if (!is.null(superintendents)) {
    expect_gt(nrow(superintendents), 0, label = "Should have superintendent records")
  }
})

# ==============================================================================
# fetch_directory() Output Tests
# ==============================================================================

test_that("fetch_directory returns data with standard schema", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  # Check basic structure
  expect_true(is.data.frame(dir_data))
  expect_gt(nrow(dir_data), 0, label = "Should have school records")

  # Check for expected columns
  expected_cols <- c(
    "state_district_id", "state_school_id",
    "district_name", "school_name",
    "school_type", "address", "city", "state", "zip"
  )

  for (col in expected_cols) {
    expect_true(col %in% names(dir_data),
                label = paste("Should have", col, "column"))
  }

  # Check column types
  expect_type(dir_data$state_district_id, "character")
  expect_type(dir_data$state_school_id, "character")
  expect_type(dir_data$district_name, "character")
  expect_type(dir_data$school_name, "character")
})

test_that("fetch_directory includes principal and superintendent data", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  # Check for admin columns
  expect_true("principal_name" %in% names(dir_data))
  expect_true("principal_email" %in% names(dir_data))
  expect_true("superintendent_name" %in% names(dir_data))
  expect_true("superintendent_email" %in% names(dir_data))

  # At least some schools should have principal info
  non_na_principals <- sum(!is.na(dir_data$principal_name))
  expect_gt(non_na_principals, 0,
            label = "Some schools should have principal names")

  # At least some districts should have superintendent info
  non_na_supers <- sum(!is.na(dir_data$superintendent_name))
  expect_gt(non_na_supers, 0,
            label = "Some districts should have superintendent names")
})

test_that("State IDs are properly formatted", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  # District IDs should be 3 digits
  expect_true(all(nchar(dir_data$state_district_id) == 3),
              label = "District IDs should be 3 digits")

  # School IDs should be 6 digits (district + location)
  expect_true(all(nchar(dir_data$state_school_id) == 6),
              label = "School IDs should be 6 digits")

  # School ID should start with district ID
  expect_true(
    all(substr(dir_data$state_school_id, 1, 3) == dir_data$state_district_id),
    label = "School ID should start with district ID"
  )
})

test_that("All schools are in New Mexico", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  expect_true(all(dir_data$state == "NM"),
              label = "All schools should be in NM")
})

test_that("fetch_directory tidy=FALSE returns raw column names", {
  skip_if_offline()
  skip_on_cran()

  dir_raw <- fetch_directory(use_cache = FALSE, tidy = FALSE)

  expect_true(is.data.frame(dir_raw))
  expect_gt(nrow(dir_raw), 0)

  # Raw data should have principals and superintendents as attributes
  principals <- attr(dir_raw, "principals")
  superintendents <- attr(dir_raw, "superintendents")

  expect_true(is.data.frame(principals) || is.null(principals))
  expect_true(is.data.frame(superintendents) || is.null(superintendents))
})

# ==============================================================================
# Data Quality Tests
# ==============================================================================

test_that("No completely empty records", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  # Every row should have at least district_name or school_name
  expect_true(
    all(!is.na(dir_data$district_name) | !is.na(dir_data$school_name)),
    label = "Every record should have district or school name"
  )
})

test_that("District names are consistent within district", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  # Group by district_id and check if district_name is consistent
  by_district <- split(dir_data$district_name, dir_data$state_district_id)

  for (district_id in names(by_district)) {
    unique_names <- unique(by_district[[district_id]])
    unique_names <- unique_names[!is.na(unique_names)]

    # Each district should have only one name (or all NA)
    expect_lte(
      length(unique_names),
      1,
      label = paste("District", district_id, "should have one name")
    )
  }
})

test_that("Superintendent info is consistent within district", {
  skip_if_offline()
  skip_on_cran()

  dir_data <- fetch_directory(use_cache = FALSE, tidy = TRUE)

  # Filter to records with superintendent info
  with_super <- dir_data[!is.na(dir_data$superintendent_name), ]

  if (nrow(with_super) > 0) {
    # Group by district and check consistency
    by_district <- split(
      with_super$superintendent_name,
      with_super$state_district_id
    )

    for (district_id in names(by_district)) {
      unique_supers <- unique(by_district[[district_id]])

      # Each district should have only one superintendent
      expect_equal(
        length(unique_supers),
        1,
        label = paste("District", district_id, "should have one superintendent")
      )
    }
  }
})

# ==============================================================================
# Cache Tests
# ==============================================================================

test_that("Directory cache functions work", {
  # Clear any existing cache
  nmschooldata::clear_directory_cache()

  # Check cache doesn't exist
  expect_false(
    nmschooldata:::cache_exists_directory("directory_tidy"),
    label = "Cache should not exist after clearing"
  )

  skip_if_offline()
  skip_on_cran()

  # Fetch with caching enabled
  dir_data1 <- fetch_directory(use_cache = TRUE, tidy = TRUE)

  # Cache should now exist
  expect_true(
    nmschooldata:::cache_exists_directory("directory_tidy"),
    label = "Cache should exist after fetch"
  )

  # Second fetch should use cache (will be faster)
  dir_data2 <- fetch_directory(use_cache = TRUE, tidy = TRUE)

  # Data should be identical
  expect_equal(nrow(dir_data1), nrow(dir_data2))
  expect_equal(ncol(dir_data1), ncol(dir_data2))

  # Clear cache again
  nmschooldata::clear_directory_cache()
  expect_false(nmschooldata:::cache_exists_directory("directory_tidy"))
})

test_that("clear_directory_cache removes cache files", {
  # Create a mock cache file
  cache_dir <- nmschooldata:::get_cache_dir()
  if (!dir.exists(cache_dir)) {
    dir.create(cache_dir, recursive = TRUE)
  }

  mock_file <- file.path(cache_dir, "directory_test.rds")
  saveRDS(data.frame(x = 1), mock_file)

  # Verify it exists
  expect_true(file.exists(mock_file))

  # Clear should remove directory cache files
  nmschooldata::clear_directory_cache()

  # Mock file should be gone
  expect_false(file.exists(mock_file))
})
