# Authors and Citation

## Authors

- **Al Martin**. Author, maintainer.

## Citation

Source:
[`DESCRIPTION`](https://github.com/almartin82/nmschooldata/blob/HEAD/DESCRIPTION)

Martin A (2026). *nmschooldata: New Mexico School Data*. R package
version 0.1.0, <https://almartin82.github.io/nmschooldata>.

    @Manual{,
      title = {nmschooldata: New Mexico School Data},
      author = {Al Martin},
      year = {2026},
      note = {R package version 0.1.0},
      url = {https://almartin82.github.io/nmschooldata},
    }
