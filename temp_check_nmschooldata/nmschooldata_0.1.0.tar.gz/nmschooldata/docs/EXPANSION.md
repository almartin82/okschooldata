# New Mexico School Data Expansion Research

**Last Updated:** 2026-01-04 **Theme Researched:** Graduation Rates

## Executive Summary

New Mexico PED provides comprehensive graduation rate data for cohorts
2008-2023, with 4-year, 5-year, and 6-year rates available. Data is
published as Excel files on web.ped.nm.gov with three distinct schema
eras requiring different parsing logic.

**Data Quality:** HIGH - Direct state DOE source with district/school
level breakdowns **Years Available:** Cohorts 2008-2023 (4-year), plus
5-year and 6-year lagged rates **Complexity:** MEDIUM - Three schema
eras, but all Excel-based with consistent subgroups

------------------------------------------------------------------------

## Data Sources Found

### Source 1: NM PED Graduation Data Files (Primary)

- **Base URL:** `https://web.ped.nm.gov/wp-content/uploads/2025/01/`
- **HTTP Status:** 200 (all verified files)
- **Format:** Excel (.xlsx)
- **Access:** Direct download, no authentication required
- **Update Frequency:** Annual (typically released 3-4 months after
  school year ends)

### Verified File URLs by Cohort

#### 4-Year Graduation Rates

| Cohort | URL                                                                                      | Schema Era |
|--------|------------------------------------------------------------------------------------------|------------|
| 2016   | `ACC_Graduation_Webfiles.Cohort.of_.2016.4.Year_.Graduation.Rates_.xlsx`                 | Legacy     |
| 2017   | `Copy-of-ACC_Graduation_Webfiles.Cohort.of_.2017.4.Year_.Graduation.Rates_12062018.xlsx` | Legacy     |
| 2018   | `Copy-of-ACC_Graduation_Webfiles.Cohort.of_.2018.4.Year_.Graduation.Rates_05102019.xlsx` | Legacy     |
| 2019   | `GradratesWEBFILE_4yr_2019_6.16.2021.xlsx`                                               | Transition |
| 2020   | `GradratesWEBFILE_4yr_2020_7.27.2021.xlsx`                                               | Transition |
| 2021   | `GradratesWEBFILE_4yr_2021_4.13.21.xlsx`                                                 | Transition |
| 2023   | `WEBFILE-4yr-Cohort-2023.xlsx`                                                           | Modern     |

#### 5-Year Graduation Rates

| Cohort | URL                                                                              | Schema Era |
|--------|----------------------------------------------------------------------------------|------------|
| 2013   | `ACC_Graduation_Webfiles.Cohort.of_.2013.5.Year_.Graduation.Rates_.xlsx`         | Legacy     |
| 2014   | `ACC_Graduation_Webfiles.Cohort.of_.2014.5.Year_.Graduation.Rates_.xlsx`         | Legacy     |
| 2015   | `ACC_Graduation_Webfiles.Cohort.of_.2015.5.Year_.Graduation.Rates_.xlsx`         | Legacy     |
| 2016   | `ACC_Graduation_Webfiles.Cohort.of_.2016.5.Year_.Graduation.Rates_07262018.xlsx` | Legacy     |
| 2018   | `GradratesWEBFILE_5yr_2018_6.16.2021.xlsx`                                       | Transition |
| 2022   | `WEBFILE-5yr-Cohort-2022.xlsx`                                                   | Modern     |

#### 6-Year Graduation Rates

| Cohort | URL                                                                              | Schema Era |
|--------|----------------------------------------------------------------------------------|------------|
| 2010   | `ACC_Graduation_Webfiles.Cohort.of_.2010.6.Year_.Graduation.Rates_.xlsx`         | Legacy     |
| 2013   | `ACC_Graduation_Webfiles.Cohort.of_.2013.6.Year_.Graduation.Rates_.xlsx`         | Legacy     |
| 2015   | `ACC_Graduation_Webfiles.Cohort.of_.2015.6.Year_.Graduation.Rates_07272018.xlsx` | Legacy     |
| 2021   | `WEBFILE-6yr-Cohort-2021.xlsx`                                                   | Modern     |

### Source 2: NM Vistas Data Portal

- **URL:** <https://www.nmvistas.org/>
- **HTTP Status:** 200
- **Format:** Web dashboard (no direct API)
- **Graduation Data:** Available but requires navigation
- **API Access:** NOT available - dashboard only
- **Recommendation:** Use direct file downloads instead

### Source 3: Achievement Data by Year Page

- **URL:**
  <https://web.ped.nm.gov/bureaus/accountability/graduation-data/>
- **Purpose:** Index page listing available graduation files
- **Note:** May contain additional files not yet discovered

------------------------------------------------------------------------

## Schema Analysis

### Schema Era 1: Legacy Format (Cohorts 2008-2018)

**Filename pattern:**
`ACC_Graduation_Webfiles.Cohort.of_.YYYY.X.Year_.Graduation.Rates_*.xlsx`

**Structure:** - Single sheet (e.g., “Cohort of 2015 5 Yr Rates”) -
Multi-row header (skip first 4 rows) - Simple 5-column format

**Columns (after header skip):** \| Column \| Name \| Type \|
Description \| \|——–\|——\|——\|————-\| \| 1 \| Code \| numeric \| 999999
= State, else district/school ID \| \| 2 \| District \| text \|
“Statewide” or district name \| \| 3 \| School \| text \| “All Schools”
or school name \| \| 4 \| Group \| text \| Subgroup (All Students, Male,
Female, etc.) \| \| 5 \| Rate \| text \| Graduation rate (may contain
“\*” for suppressed) \|

**Subgroups available (11):** - All Students - Female - Male -
Caucasian - African American - Hispanic - Asian - American Indian -
Economically Disadvantaged - Students w Disabilities - English Language
Learners

### Schema Era 2: Transition Format (Cohorts 2019-2021)

**Filename pattern:** `GradratesWEBFILE_Xyr_YYYY_*.xlsx`

**Structure:** - Two sheets: Summary sheet + “FullSizeTable” -
FullSizeTable is the main data sheet

**Columns (FullSizeTable sheet):** \| Column \| Name \| Type \|
Description \| \|——–\|——\|——\|————-\| \| 1 \| SchoolCode \| numeric \|
999999 = State, 0 = District, else school \| \| 2 \| DistrictCode \|
numeric \| 999 = State, else district code (1-585) \| \| 3 \|
DistrictName \| text \| District or “New Mexico” for state \| \| 4 \|
LocationID \| numeric \| Location identifier \| \| 5 \| SchoolName \|
text \| School name or “StateWide”/“DistrictWide” \| \| 6 \| Group \|
text \| Subgroup name \| \| 7 \| GradRate \| text \| Graduation rate \|

**Subgroups available (11):** - All, Male, Female - African American,
Caucasian, Asian, Hispanic, Native American - English Language Learners,
Economically Disadvantaged - Students with Disabilities

### Schema Era 3: Modern Format (Cohorts 2022+)

**Filename pattern:** `WEBFILE-Xyr-Cohort-YYYY.xlsx`

**Structure:** - Four sheets: Report Introduction(s), Statewide Data_M,
District Data_M, School Data_M

**Columns (all data sheets):** \| Column \| Name \| Type \| Description
\| \|——–\|——\|——\|————-\| \| 1 \| AGAID \| numeric \| Agency ID (state
assignment) \| \| 2 \| schnumb \| numeric \| School number (999999 =
state) \| \| 3 \| DistrictCode \| numeric \| 999 = State, 1-585 for
districts \| \| 4 \| DistrictName \| text \| District name or “New
Mexico” \| \| 5 \| SchoolCode \| numeric \| 999 = State, 0 = District,
else school \| \| 6 \| SchoolName \| text \| School name \| \| 7 \|
Group \| text \| Subgroup name \| \| 8 \| Numerator \| text \| Count of
graduates (may contain “\*\*\*\*\*” for suppressed) \| \| 9 \|
Denominator \| text \| Cohort size \| \| 10 \| Total_Records \| text \|
Total records \| \| 11 \| GradRate \| text \| Graduation rate percentage
\| \| 12 \| SortCode \| numeric \| Sorting order \| \| 13 \| Type \|
text/logical \| Entity type \|

**Subgroups available (17):** - All, Male, Female - African American,
Caucasian, Asian, Hispanic, Native American - English Language Learner,
Free and Reduced Lunch - Students with Disabilities, Economically
Disadvantaged - Homeless, Foster, Migrant, Military Related, Gifted

------------------------------------------------------------------------

## ID System

### District Codes

- **Range:** 1-585 (numeric)
- **State code:** 999
- **Format:** 1-3 digit integer (no leading zeros needed)
- **Examples:** 1 = Albuquerque, 4 = Roswell, 585 = charter districts

### School Codes

- **Format:** Composite - DistrictCode + SchoolCode
- **State level:** 999999
- **District level:** \[DistrictCode\]000 or SchoolCode = 0
- **School level:** DistrictCode + 3-digit school number
- **AGAID:** Alternative state-assigned agency ID (for modern format)

### Key Districts for Validation

| District Code | Name        | Expected Cohort Size |
|---------------|-------------|----------------------|
| 1             | Albuquerque | ~7,000 students      |
| 4             | Roswell     | ~800 students        |
| 89            | Las Cruces  | ~2,000 students      |

------------------------------------------------------------------------

## Known Data Issues

### Suppression Markers

- `*` - Small cell suppression (Legacy format)
- `*****` - Small cell suppression (Modern format)
- `>= 80%` or `>= 90%` - Range-masked rates (for small n)

### Data Quality Notes

1.  **Numerator/Denominator may be decimal** - Shared accountability
    uses fractional student counts
2.  **Rate may be pre-calculated range** - Small n cells show “\>=X%”
    instead of exact rate
3.  **Missing cohorts in transition period** - Some cohort/rate-type
    combinations not published
4.  **Filename inconsistencies** - “Copy-of-” prefix on some files

### Expected Zeros

- None expected at state level
- Charter schools with no high school may have no graduation data

------------------------------------------------------------------------

## Time Series Heuristics

### State Total Graduation Rates

| Rate Type | Expected Range | Red Flag If      |
|-----------|----------------|------------------|
| 4-Year    | 70-85%         | Change \> 5% YoY |
| 5-Year    | 78-90%         | Change \> 5% YoY |
| 6-Year    | 80-92%         | Change \> 5% YoY |

### State Total Cohort Size

| Metric       | Expected Range | Red Flag If       |
|--------------|----------------|-------------------|
| Total cohort | 24,000-28,000  | Change \> 10% YoY |
| Graduates    | 18,000-22,000  | Change \> 10% YoY |

### District Counts

- Expected: ~89-95 traditional districts + 30-40 charter LEAs
- Total entities: 120-135 districts

### Major District Validation (4-Year Rate)

| District    | Expected Rate Range | Expected Cohort Size |
|-------------|---------------------|----------------------|
| Albuquerque | 65-75%              | 6,500-7,500          |
| Las Cruces  | 75-85%              | 1,800-2,200          |
| Rio Rancho  | 80-90%              | 900-1,100            |

### Historical State Totals (4-Year Rate, from files)

| Cohort | Grad Rate    | Cohort Size |
|--------|--------------|-------------|
| 2020   | 76.9%        | 25,995      |
| 2022   | 79.8% (5-yr) | 25,552      |
| 2023   | 76.7%        | 26,189      |

------------------------------------------------------------------------

## Recommended Implementation

### Priority: HIGH

- Graduation rates are a key accountability metric
- Data is clean and well-structured
- Direct download access (no auth barriers)

### Complexity: MEDIUM

- Three schema eras require different parsing logic
- Subgroup standardization needed across eras
- Modern format has more complete data

### Estimated Files to Modify

1.  `R/get_raw_graduation.R` (new file)
2.  `R/process_graduation.R` (new file)
3.  `R/tidy_graduation.R` (new file)
4.  `R/fetch_graduation.R` (new file)
5.  `R/utils.R` (add graduation-specific helpers)
6.  `NAMESPACE` (export new functions)
7.  `DESCRIPTION` (update version)

### Implementation Steps

1.  **Create get_raw_grad()**
    - Detect schema era from cohort year
    - Download appropriate file
    - Return raw tibble with sheet selection logic
2.  **Create process_grad()**
    - Normalize column names across eras
    - Standardize subgroup names
    - Parse suppressed values to NA
    - Add cohort_year and rate_type columns
3.  **Create tidy_grad()**
    - Pivot to long format if needed
    - Standardize entity type (state/district/school)
    - Add calculated fields (graduation_count from rate \* cohort_size)
4.  **Create fetch_grad()**
    - Main user-facing function
    - Parameters: cohort_year, rate_type (4/5/6), tidy, use_cache
    - Validate inputs and orchestrate pipeline

### Schema Era Detection Pattern

``` r
get_grad_schema_era <- function(cohort_year) {
  if (cohort_year <= 2018) return("legacy")
  if (cohort_year <= 2021) return("transition")
  return("modern")
}
```

### Subgroup Standardization Map

``` r
standardize_subgroup <- function(group) {
  mapping <- c(
    "All Students" = "all",
    "All" = "all",
    "Female" = "female",
    "Male" = "male",
    "African American" = "black",
    "Caucasian" = "white",
    "Asian" = "asian",
    "Hispanic" = "hispanic",
    "American Indian" = "native_american",
    "Native American" = "native_american",
    "English Language Learners" = "ell",
    "English Language Learner" = "ell",
    "Economically Disadvantaged" = "econ_disadvantaged",
    "Free and Reduced Lunch" = "frpl",
    "Students w Disabilities" = "swd",
    "Students with Disabilities" = "swd",
    "Homeless" = "homeless",
    "Foster" = "foster",
    "Migrant" = "migrant",
    "Military Related" = "military",
    "Gifted" = "gifted"
  )
  mapping[group]
}
```

------------------------------------------------------------------------

## Test Requirements

### Raw Data Fidelity Tests Needed

#### State-Level 4-Year Rate Verification

| Cohort | Expected Rate | Source                                          |
|--------|---------------|-------------------------------------------------|
| 2020   | 76.9%         | GradratesWEBFILE_4yr_2020 (StateWide, All)      |
| 2023   | 76.7%         | WEBFILE-4yr-Cohort-2023 (Statewide Data_M, All) |

#### State-Level 5-Year Rate Verification

| Cohort | Expected Rate | Source                                                                    |
|--------|---------------|---------------------------------------------------------------------------|
| 2015   | 75%           | ACC_Graduation_Webfiles.Cohort.of\_.2015.5.Year (Statewide, All Students) |
| 2022   | 79.8%         | WEBFILE-5yr-Cohort-2022 (Statewide Data_M, All)                           |

#### District-Level Verification

| Cohort | District        | Expected Rate | Source                                    |
|--------|-----------------|---------------|-------------------------------------------|
| 2023   | Albuquerque (1) | 69.9%         | WEBFILE-4yr-Cohort-2023 (District Data_M) |

### Data Quality Checks

``` r
test_that("graduation rates are valid percentages", {
  data <- fetch_grad(2023, rate_type = 4, tidy = TRUE)
  expect_true(all(data$grad_rate >= 0 | is.na(data$grad_rate)))
  expect_true(all(data$grad_rate <= 100 | is.na(data$grad_rate)))
})

test_that("state total exists for all subgroups", {
  data <- fetch_grad(2023, rate_type = 4, tidy = TRUE)
  state_data <- data[data$entity_type == "state", ]
  expect_equal(nrow(state_data), 17)  # 17 subgroups in modern format
})

test_that("major districts present", {
  data <- fetch_grad(2023, rate_type = 4, tidy = TRUE)
  district_data <- data[data$entity_type == "district" & data$subgroup == "all", ]
  expect_true("ALBUQUERQUE" %in% toupper(district_data$district_name))
  expect_true("LAS CRUCES" %in% toupper(district_data$district_name))
  expect_true("RIO RANCHO" %in% toupper(district_data$district_name))
})

test_that("cohort size is reasonable", {
  data <- fetch_grad(2023, rate_type = 4, tidy = FALSE)
  state_all <- data[data$Group == "All" & data$DistrictName == "New Mexico", ]
  expect_gt(state_all$Denominator, 24000)
  expect_lt(state_all$Denominator, 30000)
})
```

### LIVE Pipeline Tests

1.  **URL Availability** - All verified URLs return HTTP 200
2.  **File Download** - Files download with size \> 50KB
3.  **File Parsing** - readxl can read all sheets
4.  **Column Structure** - Expected columns exist per schema era
5.  **Year Filtering** - Correct cohort extracted
6.  **Aggregation** - State = sum of district graduates
7.  **Data Quality** - No negative rates, no rates \> 100%
8.  **Output Fidelity** - tidy=TRUE matches raw values

------------------------------------------------------------------------

## Files Enumerated But Not Yet Verified

The following cohort/rate combinations may exist but weren’t found in
search: - 4-Year: Cohorts 2008-2015, 2022, 2024 - 5-Year: Cohorts
2008-2012, 2017, 2019-2021 - 6-Year: Cohorts 2008-2009, 2011-2012, 2014,
2016-2020, 2022+

**Recommendation:** Before implementation, do a comprehensive directory
listing or contact NM PED to get complete file inventory.

------------------------------------------------------------------------

## References

- [NM PED Graduation Data
  Page](https://web.ped.nm.gov/bureaus/accountability/graduation-data/)
- [NM Vistas Data Portal](https://www.nmvistas.org/)
- [Graduation Technical
  Manual](https://web.ped.nm.gov/wp-content/uploads/2025/01/ACC_Graduation_instructionalguides_Graduation.Technical.Manual.pdf)
- Contact: <grad.questions@ped.nm.gov>
