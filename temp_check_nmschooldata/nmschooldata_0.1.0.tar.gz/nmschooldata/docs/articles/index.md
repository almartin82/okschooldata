# Articles

### All vignettes

- [Understanding NM PED Data
  Availability](https://almartin82.github.io/nmschooldata/articles/data_availability.md):
- [10 Insights from New Mexico School Enrollment
  Data](https://almartin82.github.io/nmschooldata/articles/enrollment_hooks.md):
