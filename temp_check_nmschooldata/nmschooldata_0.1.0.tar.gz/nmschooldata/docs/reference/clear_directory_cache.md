# Clear school directory cache

Removes cached school directory data files.

## Usage

``` r
clear_directory_cache()
```

## Value

Invisibly returns the number of files removed

## Examples

``` r
if (FALSE) { # \dontrun{
# Clear cached directory data
clear_directory_cache()
} # }
```
