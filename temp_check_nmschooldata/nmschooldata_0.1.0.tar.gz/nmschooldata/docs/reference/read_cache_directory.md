# Read directory data from cache

Read directory data from cache

## Usage

``` r
read_cache_directory(cache_type)
```

## Arguments

- cache_type:

  Type of cache ("directory_tidy" or "directory_raw")

## Value

Cached data frame
