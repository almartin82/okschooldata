# Build NM PED school directory download URL

Constructs the download URL for school directory CSV files. The file
naming pattern uses dates, so this function finds the most recent.

## Usage

``` r
build_directory_url(file_type)
```

## Arguments

- file_type:

  One of: "schools", "principal_elementary", "principal_mid",
  "principal_high", "superintendent"

## Value

URL string
