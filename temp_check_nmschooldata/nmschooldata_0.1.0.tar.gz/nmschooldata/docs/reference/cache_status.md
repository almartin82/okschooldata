# Show cache status

Lists all cached data files with their size and age.

## Usage

``` r
cache_status()
```

## Value

Data frame with cache information (invisibly)

## Examples

``` r
if (FALSE) { # \dontrun{
cache_status()
} # }
```
