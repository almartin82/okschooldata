# Create district-level aggregates from school data

Aggregates school-level data to district level. Groups by district_id
and sums all numeric columns.

## Usage

``` r
create_district_aggregate(df, end_year)
```

## Arguments

- df:

  Processed data frame with school-level data

- end_year:

  School year end

## Value

Data frame with district-level aggregates
