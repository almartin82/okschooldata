# Download a specific directory file

Downloads one of the school directory CSV files from NM PED.

## Usage

``` r
download_directory_file(file_type)
```

## Arguments

- file_type:

  One of: "schools", "principal_elementary", "principal_mid",
  "principal_high", "superintendent"

## Value

Data frame with file contents
