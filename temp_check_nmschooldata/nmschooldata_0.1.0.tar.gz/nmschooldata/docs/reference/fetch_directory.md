# Fetch New Mexico school directory data

Downloads and processes school directory data from the New Mexico Public
Education Department. This includes all public schools and districts
with contact information, addresses, and administrator names.

## Usage

``` r
fetch_directory(end_year = NULL, tidy = TRUE, use_cache = TRUE)
```

## Arguments

- end_year:

  Currently unused. The directory data represents current schools and is
  not year-specific. Included for API consistency with other fetch
  functions.

- tidy:

  If TRUE (default), returns data in a standardized format with
  consistent column names. If FALSE, returns raw column names from NM
  PED.

- use_cache:

  If TRUE (default), uses locally cached data when available. Set to
  FALSE to force re-download from NM PED.

## Value

A tibble with school directory data. Columns include:

- `state_district_id`: 3-digit district code

- `state_school_id`: Full location code (district + location)

- `district_name`: District name

- `school_name`: School name

- `school_type`: Type of school (Elementary, Middle, High, etc.)

- `district_type`: District organization type

- `address`: Street address

- `city`: City

- `state`: State (always "NM")

- `zip`: ZIP code

- `principal_name`: Principal name (when available)

- `principal_email`: Principal email (when available)

- `superintendent_name`: Superintendent name (when available)

- `superintendent_email`: Superintendent email (when available)

- `website`: School/district website

## Details

The directory data is downloaded as CSV files from the NM PED website.
Multiple files are merged to provide a comprehensive view: the main
schools file is joined with principal and superintendent lists to
include administrator contact information.

## Examples

``` r
if (FALSE) { # \dontrun{
# Get school directory data
dir_data <- fetch_directory()

# Get raw format (original NM PED column names)
dir_raw <- fetch_directory(tidy = FALSE)

# Force fresh download (ignore cache)
dir_fresh <- fetch_directory(use_cache = FALSE)

# Filter to active schools only
library(dplyr)
albuquerque <- dir_data |>
  filter(grepl("Albuquerque", district_name, ignore.case = TRUE))

# Find all high schools
high_schools <- dir_data |>
  filter(school_type == "High School")
} # }
```
