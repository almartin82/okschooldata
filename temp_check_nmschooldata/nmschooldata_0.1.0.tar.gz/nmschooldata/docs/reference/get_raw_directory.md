# Get raw school directory data from NM PED

Downloads the raw school directory CSV files from the New Mexico Public
Education Department website and merges them.

## Usage

``` r
get_raw_directory()
```

## Value

Raw data frame as downloaded from NM PED
