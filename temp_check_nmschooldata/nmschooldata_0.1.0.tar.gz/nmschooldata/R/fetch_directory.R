# ==============================================================================
# School Directory Data Fetching Functions
# ==============================================================================
#
# This file contains functions for downloading school directory data from the
# New Mexico Public Education Department (PED) website.
#
# Data source: https://web.ped.nm.gov/new-mexico-public-schools-directory/
#
# Available files:
# - nm-schools.csv: School listing with district/location codes
# - principal-elementary.csv: Elementary school principals
# - principal-jr-mid-high.csv: Middle/junior high principals
# - principal-secondary.csv: High school principals
# - superintendent.csv: District superintendents
#
# ==============================================================================

#' Fetch New Mexico school directory data
#'
#' Downloads and processes school directory data from the New Mexico Public
#' Education Department. This includes all public schools and districts
#' with contact information, addresses, and administrator names.
#'
#' @param end_year Currently unused. The directory data represents current
#'   schools and is not year-specific. Included for API consistency with
#'   other fetch functions.
#' @param tidy If TRUE (default), returns data in a standardized format with
#'   consistent column names. If FALSE, returns raw column names from NM PED.
#' @param use_cache If TRUE (default), uses locally cached data when available.
#'   Set to FALSE to force re-download from NM PED.
#' @return A tibble with school directory data. Columns include:
#'   \itemize{
#'     \item \code{state_district_id}: 3-digit district code
#'     \item \code{state_school_id}: Full location code (district + location)
#'     \item \code{district_name}: District name
#'     \item \code{school_name}: School name
#'     \item \code{school_type}: Type of school (Elementary, Middle, High, etc.)
#'     \item \code{district_type}: District organization type
#'     \item \code{address}: Street address
#'     \item \code{city}: City
#'     \item \code{state}: State (always "NM")
#'     \item \code{zip}: ZIP code
#'     \item \code{principal_name}: Principal name (when available)
#'     \item \code{principal_email}: Principal email (when available)
#'     \item \code{superintendent_name}: Superintendent name (when available)
#'     \item \code{superintendent_email}: Superintendent email (when available)
#'     \item \code{website}: School/district website
#'   }
#' @details
#' The directory data is downloaded as CSV files from the NM PED website.
#' Multiple files are merged to provide a comprehensive view: the main schools
#' file is joined with principal and superintendent lists to include
#' administrator contact information.
#'
#' @export
#' @examples
#' \dontrun{
#' # Get school directory data
#' dir_data <- fetch_directory()
#'
#' # Get raw format (original NM PED column names)
#' dir_raw <- fetch_directory(tidy = FALSE)
#'
#' # Force fresh download (ignore cache)
#' dir_fresh <- fetch_directory(use_cache = FALSE)
#'
#' # Filter to active schools only
#' library(dplyr)
#' albuquerque <- dir_data |>
#'   filter(grepl("Albuquerque", district_name, ignore.case = TRUE))
#'
#' # Find all high schools
#' high_schools <- dir_data |>
#'   filter(school_type == "High School")
#' }
fetch_directory <- function(end_year = NULL, tidy = TRUE, use_cache = TRUE) {

  # Determine cache type based on tidy parameter
  cache_type <- if (tidy) "directory_tidy" else "directory_raw"

  # Check cache first
  if (use_cache && cache_exists_directory(cache_type)) {
    message("Using cached school directory data")
    return(read_cache_directory(cache_type))
  }

  # Get raw data from NM PED
  raw <- get_raw_directory()

  # Process to standard schema
  if (tidy) {
    result <- process_directory(raw)
  } else {
    result <- raw
  }

  # Cache the result
  if (use_cache) {
    write_cache_directory(result, cache_type)
  }

  result
}


#' Get raw school directory data from NM PED
#'
#' Downloads the raw school directory CSV files from the New Mexico
#' Public Education Department website and merges them.
#'
#' @return Raw data frame as downloaded from NM PED
#' @keywords internal
get_raw_directory <- function() {

  message("Downloading school directory data from NM PED...")

  # Download all available files
  schools <- download_directory_file("schools")
  principals_elem <- download_directory_file("principal_elementary")
  principals_mid <- download_directory_file("principal_mid")
  principals_high <- download_directory_file("principal_high")
  superintendents <- download_directory_file("superintendent")

  # Add source indicators and standardize column names for merging
  schools$data_source <- "schools"
  principals_elem$data_source <- "principal_elementary"
  principals_mid$data_source <- "principal_mid"
  principals_high$data_source <- "principal_high"
  superintendents$data_source <- "superintendent"

  # The schools file is the base; we'll join principal/superintendent info
 result <- schools

  # Create a principals combined table
  principals <- dplyr::bind_rows(
    principals_elem,
    principals_mid,
    principals_high
  )

  # Convert to tibbles for consistency
  result <- dplyr::as_tibble(result)
  principals <- dplyr::as_tibble(principals)
  superintendents <- dplyr::as_tibble(superintendents)

  # Store related tables as attributes for later processing
  attr(result, "principals") <- principals
  attr(result, "superintendents") <- superintendents

  message(paste("Loaded", nrow(result), "school records"))
  message(paste("Loaded", nrow(principals), "principal records"))
  message(paste("Loaded", nrow(superintendents), "superintendent records"))

  result
}


#' Download a specific directory file
#'
#' Downloads one of the school directory CSV files from NM PED.
#'
#' @param file_type One of: "schools", "principal_elementary", "principal_mid",
#'   "principal_high", "superintendent"
#' @return Data frame with file contents
#' @keywords internal
download_directory_file <- function(file_type) {

  url <- build_directory_url(file_type)

  # Download to temp file
  temp_file <- tempfile(fileext = ".csv")

  response <- httr::GET(
    url,
    httr::write_disk(temp_file, overwrite = TRUE),
    httr::timeout(120)
  )

  if (httr::http_error(response)) {
    warning(paste("Failed to download", file_type, "file: HTTP",
                  httr::status_code(response)))
    return(data.frame())
  }

  # Check file size
  file_info <- file.info(temp_file)
  if (file_info$size < 100) {
    warning(paste("Downloaded file for", file_type, "is too small, may be empty"))
    return(data.frame())
  }

  # Read CSV - handle BOM and encoding
  df <- readr::read_csv(
    temp_file,
    col_types = readr::cols(.default = readr::col_character()),
    show_col_types = FALSE,
    locale = readr::locale(encoding = "UTF-8")
  )

  df
}


#' Build NM PED school directory download URL
#'
#' Constructs the download URL for school directory CSV files.
#' The file naming pattern uses dates, so this function finds the most recent.
#'
#' @param file_type One of: "schools", "principal_elementary", "principal_mid",
#'   "principal_high", "superintendent"
#' @return URL string
#' @keywords internal
build_directory_url <- function(file_type) {

  # Base URL for NM PED directory files
  base_url <- "https://web.ped.nm.gov/wp-content/uploads/2025/01/"

  # File name patterns (using known pattern from 2024-2025)
  file_names <- list(
    schools = "09-2024-nmpsd-nm-schools.csv",
    principal_elementary = "09-2024-nmpsd-principal-elementary.csv",
    principal_mid = "09-2024-nmpsd-principal-jr-mid-high.csv",
    principal_high = "09-2024-nmpsd-principal-secondary.csv",
    superintendent = "09-2024-nmpsd-superintendent.csv"
  )

  if (!file_type %in% names(file_names)) {
    stop(paste("Unknown file type:", file_type,
               "\nValid types:", paste(names(file_names), collapse = ", ")))
  }

  paste0(base_url, file_names[[file_type]])
}


#' Process raw school directory data to standard schema
#'
#' Takes raw school directory data from NM PED and standardizes column names,
#' types, and merges principal/superintendent information.
#'
#' @param raw_data Raw data frame from get_raw_directory()
#' @return Processed data frame with standard schema
#' @keywords internal
process_directory <- function(raw_data) {

  # Get the associated principals and superintendents data
  principals <- attr(raw_data, "principals")
  superintendents <- attr(raw_data, "superintendents")

  # Clean column names in schools data
  names(raw_data) <- clean_names(names(raw_data))

  # Build standardized result from schools data
  result <- dplyr::tibble(
    state_district_id = sprintf("%03d", as.integer(raw_data$districtcode)),
    state_school_id = paste0(
      sprintf("%03d", as.integer(raw_data$districtcode)),
      sprintf("%03d", as.integer(raw_data$locationcode))
    ),
    district_name = trimws(raw_data$districtname),
    school_name = trimws(raw_data$schoolname),
    school_type = trimws(raw_data$schoolcategory),
    district_type = trimws(raw_data$districtorgtype),
    location_type = trimws(raw_data$locationorgtype),
    address = trimws(raw_data$physicaladdress_streetnumbername),
    city = trimws(raw_data$physicaladdress_city),
    state = "NM",
    zip = trimws(raw_data$physicaladdress_postalcode),
    last_modified = raw_data$educationorganization_lastmodifieddate
  )

  # Process and join principals if available
  if (!is.null(principals) && nrow(principals) > 0) {
    names(principals) <- clean_names(names(principals))

    # Create principal lookup - deduplicate by district + school name
    principals_clean <- principals |>
      dplyr::mutate(
        state_district_id = sprintf("%03d", as.integer(.data$districtcode)),
        principal_name = trimws(paste(.data$firstname, .data$lastname)),
        principal_email = trimws(.data$electronicmailaddress),
        schoolname = trimws(.data$schoolname)
      ) |>
      dplyr::select(
        "state_district_id", "schoolname",
        "principal_name", "principal_email"
      ) |>
      # Keep only one principal per school (first one if duplicates)
      dplyr::distinct(.data$state_district_id, .data$schoolname, .keep_all = TRUE)

    # Join principals - match on district_id and school_name
    result <- result |>
      dplyr::left_join(
        principals_clean,
        by = c("state_district_id", "school_name" = "schoolname")
      )
  } else {
    result$principal_name <- NA_character_
    result$principal_email <- NA_character_
  }

  # Process and join superintendents if available
  if (!is.null(superintendents) && nrow(superintendents) > 0) {
    names(superintendents) <- clean_names(names(superintendents))

    # Create superintendent lookup (one per district)
    supers_clean <- superintendents |>
      dplyr::mutate(
        state_district_id = sprintf("%03d", as.integer(.data$districtcode)),
        superintendent_name = trimws(paste(.data$firstname, .data$lastname)),
        superintendent_email = trimws(.data$electronicmailaddress),
        website = trimws(.data$website)
      ) |>
      dplyr::select(
        "state_district_id",
        "superintendent_name", "superintendent_email", "website"
      ) |>
      dplyr::distinct(.data$state_district_id, .keep_all = TRUE)

    # Join superintendents - match on district_id only
    result <- result |>
      dplyr::left_join(
        supers_clean,
        by = "state_district_id",
        relationship = "many-to-one"
      )
  } else {
    result$superintendent_name <- NA_character_
    result$superintendent_email <- NA_character_
    result$website <- NA_character_
  }

  # Reorder columns for consistency
  preferred_order <- c(
    "state_district_id", "state_school_id",
    "district_name", "school_name",
    "school_type", "district_type", "location_type",
    "address", "city", "state", "zip",
    "principal_name", "principal_email",
    "superintendent_name", "superintendent_email",
    "website", "last_modified"
  )

  existing_cols <- preferred_order[preferred_order %in% names(result)]
  other_cols <- setdiff(names(result), preferred_order)

  result <- result |>
    dplyr::select(dplyr::all_of(c(existing_cols, other_cols)))

  result
}


# ==============================================================================
# Directory-specific cache functions
# ==============================================================================

#' Build cache file path for directory data
#'
#' @param cache_type Type of cache ("directory_tidy" or "directory_raw")
#' @return File path string
#' @keywords internal
build_cache_path_directory <- function(cache_type) {
  cache_dir <- get_cache_dir()
  file.path(cache_dir, paste0(cache_type, ".rds"))
}


#' Check if cached directory data exists
#'
#' @param cache_type Type of cache ("directory_tidy" or "directory_raw")
#' @param max_age Maximum age in days (default 30). Set to Inf to ignore age.
#' @return Logical indicating if valid cache exists
#' @keywords internal
cache_exists_directory <- function(cache_type, max_age = 30) {
  cache_path <- build_cache_path_directory(cache_type)

  if (!file.exists(cache_path)) {
    return(FALSE)
  }

  # Check age
  file_info <- file.info(cache_path)
  age_days <- as.numeric(difftime(Sys.time(), file_info$mtime, units = "days"))

  age_days <= max_age
}


#' Read directory data from cache
#'
#' @param cache_type Type of cache ("directory_tidy" or "directory_raw")
#' @return Cached data frame
#' @keywords internal
read_cache_directory <- function(cache_type) {
  cache_path <- build_cache_path_directory(cache_type)
  readRDS(cache_path)
}


#' Write directory data to cache
#'
#' @param data Data frame to cache
#' @param cache_type Type of cache ("directory_tidy" or "directory_raw")
#' @return Invisibly returns the cache path
#' @keywords internal
write_cache_directory <- function(data, cache_type) {
  cache_path <- build_cache_path_directory(cache_type)
  cache_dir <- dirname(cache_path)

  if (!dir.exists(cache_dir)) {
    dir.create(cache_dir, recursive = TRUE)
  }

  saveRDS(data, cache_path)
  invisible(cache_path)
}


#' Clear school directory cache
#'
#' Removes cached school directory data files.
#'
#' @return Invisibly returns the number of files removed
#' @export
#' @examples
#' \dontrun{
#' # Clear cached directory data
#' clear_directory_cache()
#' }
clear_directory_cache <- function() {
  cache_dir <- get_cache_dir()

  if (!dir.exists(cache_dir)) {
    message("Cache directory does not exist")
    return(invisible(0))
  }

  files <- list.files(cache_dir, pattern = "^directory_", full.names = TRUE)

  if (length(files) > 0) {
    file.remove(files)
    message(paste("Removed", length(files), "cached directory file(s)"))
  } else {
    message("No cached directory files to remove")
  }

  invisible(length(files))
}
