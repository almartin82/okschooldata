## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----load-packages------------------------------------------------------------
library(nmschooldata)
library(dplyr)

## ----era1-example, eval=FALSE-------------------------------------------------
# # Era 1 data structure
# enr_2017 <- fetch_enr(2017, use_cache = TRUE)
# 
# # Only 'total' subgroup available
# unique(enr_2017$subgroup)
# #> [1] "total"
# 
# # But all grade levels are present
# unique(enr_2017$grade_level)
# #> [1] "TOTAL" "PK" "K" "01" "02" "03" "04" "05" "06" "07" "08" "09" "10" "11" "12"

## ----era2a-example, eval=FALSE------------------------------------------------
# # Era 2a data structure
# enr_2023 <- fetch_enr(2023, use_cache = TRUE)
# 
# # All 13 subgroups available
# unique(enr_2023$subgroup)
# #>  [1] "total" "white" "black" "hispanic" "asian" "native_american"
# #>  [7] "pacific_islander" "multiracial" "male" "female" "special_ed"
# #> [13] "ell" "econ_disadv"
# 
# # Only TOTAL grade level
# unique(enr_2023$grade_level)
# #> [1] "TOTAL"

## ----era2b-example, eval=FALSE------------------------------------------------
# # 2024 data structure (shows a warning message)
# enr_2024 <- fetch_enr(2024, use_cache = TRUE)
# #> Note: 2024 (SY 2023-24) only has 80-Day enrollment data available.
# #>       40-Day subgroup data has not been published by NM PED.
# 
# # Only 'total' subgroup available
# unique(enr_2024$subgroup)
# #> [1] "total"
# 
# # But all grade levels are present
# unique(enr_2024$grade_level)
# #> [1] "TOTAL" "PK" "K" "01" "02" "03" "04" "05" "06" "07" "08" "09" "10" "11" "12"

## ----era2c-example, eval=FALSE------------------------------------------------
# # 2025 data structure
# enr_2025 <- fetch_enr(2025, use_cache = TRUE)
# 
# # All three levels available
# table(enr_2025$type[enr_2025$subgroup == "total" & enr_2025$grade_level == "TOTAL"])
# #> District   School    State
# #>      155      876        1
# 
# # All 13 subgroups available
# length(unique(enr_2025$subgroup))
# #> [1] 13

## ----state-totals, eval=FALSE-------------------------------------------------
# # For consistent state totals, use years with 40-Day data
# enr <- fetch_enr_multi(c(2019:2023, 2025, use_cache = TRUE))
# 
# state_totals <- enr |>
#   filter(is_state, subgroup == "total", grade_level == "TOTAL") |>
#   select(end_year, n_students)
# 
# state_totals

## ----demo-trends, eval=FALSE--------------------------------------------------
# # Demographics only available for 2019-2023, 2025
# enr <- fetch_enr_multi(c(2019:2023, 2025, use_cache = TRUE))
# 
# hispanic_trend <- enr |>
#   filter(is_state, subgroup == "hispanic", grade_level == "TOTAL") |>
#   select(end_year, n_students, pct)
# 
# hispanic_trend

## ----grade-data, eval=FALSE---------------------------------------------------
# # Grade breakdowns only for Era 1 (2016-2018) and 2024
# enr_2017 <- fetch_enr(2017, use_cache = TRUE)
# 
# kindergarten_by_district <- enr_2017 |>
#   filter(is_district, subgroup == "total", grade_level == "K") |>
#   select(district_name, n_students) |>
#   arrange(desc(n_students))
# 
# kindergarten_by_district

