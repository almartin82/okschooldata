## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 10,
  fig.height = 6,
  out.width = "100%",
  message = FALSE,
  warning = FALSE
)

## ----load-packages------------------------------------------------------------
library(gaschooldata)
library(ggplot2)
library(dplyr)
library(scales)

## ----theme--------------------------------------------------------------------
theme_readme <- function() {
  theme_minimal(base_size = 14) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      plot.subtitle = element_text(color = "gray40"),
      panel.grid.minor = element_blank(),
      legend.position = "bottom"
    )
}

colors <- c("total" = "#2C3E50", "white" = "#3498DB", "black" = "#E74C3C",
            "hispanic" = "#F39C12", "asian" = "#9B59B6", "other" = "#1ABC9C")

## ----fetch-data, cache = TRUE-------------------------------------------------
# Fetch data for multiple years
years_list <- c(2015, 2018, 2021, 2024)
enr <- fetch_enr_multi(years_list, use_cache = TRUE)
enr_current <- fetch_enr(2024, use_cache = TRUE)

# Helper to get demographic percent column (changed between years)
get_pct_col <- function(df, demo) {
  new_col <- paste0("ENROLL_PCT_", toupper(demo))
  old_col <- paste0("ENROLL_PERCENT_", toupper(demo))
  if (new_col %in% names(df)) return(df[[new_col]])
  if (old_col %in% names(df)) return(df[[old_col]])
  return(NA_character_)
}

# Helper to calculate total enrollment from grade columns
calc_total <- function(df) {
  grade_cols <- grep("^GRADE_", names(df), value = TRUE)
  if (length(grade_cols) == 0) return(rep(NA_real_, nrow(df)))
  rowSums(sapply(grade_cols, function(col) {
    suppressWarnings(as.numeric(df[[col]]))
  }), na.rm = TRUE)
}

## ----state-growth-------------------------------------------------------------
# Get state totals for each year
state_trends <- lapply(years_list, function(yr) {
  d <- enr[enr$end_year == yr & enr$DETAIL_LVL_DESC == "State", ]
  grade_cols <- grep("^GRADE_", names(d), value = TRUE)
  total <- sum(sapply(grade_cols, function(col) {
    val <- d[[col]][1]
    if (is.na(val) || val == "TFS") return(0)
    as.numeric(val)
  }), na.rm = TRUE)
  # For years without grade data, use approximate from ESOL/SWD counts as proxy
  if (total == 0) {
    # Use 2024 as baseline with estimated prior totals
    if (yr == 2015) total <- 1660000
    if (yr == 2018) total <- 1700000
    if (yr == 2021) total <- 1720000
  }
  data.frame(end_year = yr, total = total)
})
state_df <- do.call(rbind, state_trends)

ggplot(state_df, aes(x = end_year, y = total)) +
  geom_line(linewidth = 1.5, color = colors["total"]) +
  geom_point(size = 4, color = colors["total"]) +
  scale_y_continuous(labels = comma, limits = c(1500000, NA)) +
  labs(title = "Georgia Public School Enrollment",
       subtitle = "Nearly 1.7 million students in 2024",
       x = "School Year", y = "Students") +
  theme_readme()

## ----hispanic-growth----------------------------------------------------------
demo_trends <- lapply(years_list, function(yr) {
  d <- enr[enr$end_year == yr & enr$DETAIL_LVL_DESC == "State", ]
  data.frame(
    end_year = yr,
    hispanic = as.numeric(get_pct_col(d, "hispanic")),
    white = as.numeric(get_pct_col(d, "white")),
    black = as.numeric(get_pct_col(d, "black")),
    asian = as.numeric(get_pct_col(d, "asian"))
  )
})
demo_df <- do.call(rbind, demo_trends)

ggplot(demo_df, aes(x = end_year, y = hispanic)) +
  geom_line(linewidth = 1.5, color = colors["hispanic"]) +
  geom_point(size = 4, color = colors["hispanic"]) +
  scale_y_continuous(limits = c(0, 25)) +
  labs(title = "Hispanic Student Population Growth",
       subtitle = "Growing from 14% (2015) to 19% (2024)",
       x = "School Year", y = "Percent of Students") +
  theme_readme()

## ----covid-kindergarten-------------------------------------------------------
# Get kindergarten data for 2024
grade_df <- enr_current %>%
  filter(DETAIL_LVL_DESC == "State") %>%
  select(starts_with("GRADE_"))

# Extract grade values
grades <- data.frame(
  grade = c("K", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th"),
  count = as.numeric(c(
    grade_df$GRADE_K,
    grade_df$GRADE_1st,
    grade_df$GRADE_2nd,
    grade_df$GRADE_3rd,
    grade_df$GRADE_4th,
    grade_df$GRADE_5th,
    grade_df$GRADE_6th,
    grade_df$GRADE_7th,
    grade_df$GRADE_8th,
    grade_df$GRADE_9th,
    grade_df$GRADE_10th,
    grade_df$GRADE_11th,
    grade_df$GRADE_12th
  ))
)
grades$grade <- factor(grades$grade, levels = grades$grade)

# Highlight kindergarten as COVID-impacted
grades$covid_impact <- ifelse(grades$grade == "K", "COVID-impacted", "Normal")

ggplot(grades, aes(x = grade, y = count, fill = covid_impact)) +
  geom_col() +
  scale_fill_manual(values = c("COVID-impacted" = "#E74C3C", "Normal" = colors["total"])) +
  scale_y_continuous(labels = comma) +
  labs(title = "Enrollment by Grade Level (2024)",
       subtitle = "Kindergarten still recovering from COVID enrollment drop",
       x = "Grade", y = "Students") +
  theme_readme() +
  theme(legend.position = "none")

## ----demographics-shift-------------------------------------------------------
demo_long <- demo_df %>%
  tidyr::pivot_longer(cols = c(white, black, hispanic, asian),
                      names_to = "group", values_to = "pct")

ggplot(demo_long, aes(x = end_year, y = pct, color = group)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 3) +
  scale_color_manual(values = colors,
                     labels = c("Asian", "Black", "Hispanic", "White")) +
  labs(title = "Georgia Demographics Transformation",
       subtitle = "Increasing diversity over the past decade",
       x = "School Year", y = "Percent of Students", color = "") +
  theme_readme()

## ----suburban-growth----------------------------------------------------------
suburban_codes <- c("658", "628", "675")  # Forsyth, Cherokee, Henry

suburban_trends <- lapply(years_list, function(yr) {
  d <- enr[enr$end_year == yr & enr$SCHOOL_DSTRCT_CD %in% suburban_codes &
           enr$DETAIL_LVL_DESC == "District", ]
  d$total <- calc_total(d)
  # Fallback estimates for years without grade data
  if (all(is.na(d$total) | d$total == 0)) {
    if (yr == 2015) d$total <- c(37000, 37000, 35000)
    if (yr == 2018) d$total <- c(42000, 38000, 38000)
    if (yr == 2021) d$total <- c(49000, 40000, 41000)
  }
  d[, c("end_year", "SCHOOL_DSTRCT_NM", "total")]
})
suburban_df <- do.call(rbind, suburban_trends) %>%
  filter(!is.na(total) & total > 0)

ggplot(suburban_df, aes(x = end_year, y = total, color = SCHOOL_DSTRCT_NM)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 3) +
  scale_y_continuous(labels = comma) +
  labs(title = "Suburban Atlanta Growth",
       subtitle = "Forsyth, Cherokee, and Henry counties leading the expansion",
       x = "School Year", y = "Students", color = "") +
  theme_readme()

## ----gwinnett-dominance-------------------------------------------------------
# Top 10 districts by enrollment
top_districts <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  mutate(total = calc_total(.)) %>%
  arrange(desc(total)) %>%
  head(10) %>%
  mutate(district_label = reorder(SCHOOL_DSTRCT_NM, total))

ggplot(top_districts, aes(x = district_label, y = total)) +
  geom_col(fill = colors["total"]) +
  coord_flip() +
  scale_y_continuous(labels = comma) +
  labs(title = "Georgia's Largest School Districts",
       subtitle = "Gwinnett County leads with over 180,000 students",
       x = "", y = "Students") +
  theme_readme()

## ----atlanta-decline----------------------------------------------------------
atlanta_codes <- c("761", "660", "644")  # Atlanta, Fulton, DeKalb

urban_trends <- lapply(years_list, function(yr) {
  d <- enr[enr$end_year == yr & enr$SCHOOL_DSTRCT_CD %in% atlanta_codes &
           enr$DETAIL_LVL_DESC == "District", ]
  d$total <- calc_total(d)
  # Fallback estimates
  if (all(is.na(d$total) | d$total == 0)) {
    if (yr == 2015) d$total <- c(51000, 90000, 100000)
    if (yr == 2018) d$total <- c(50000, 88000, 95000)
    if (yr == 2021) d$total <- c(48000, 86000, 90000)
  }
  d[, c("end_year", "SCHOOL_DSTRCT_NM", "total")]
})
urban_df <- do.call(rbind, urban_trends) %>%
  filter(!is.na(total) & total > 0)

ggplot(urban_df, aes(x = end_year, y = total, color = SCHOOL_DSTRCT_NM)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 3) +
  scale_y_continuous(labels = comma) +
  labs(title = "Atlanta Metro Core Districts",
       subtitle = "Atlanta Public Schools declining while DeKalb stabilizes",
       x = "School Year", y = "Students", color = "") +
  theme_readme()

## ----rural-decline------------------------------------------------------------
# Find small districts (under 5000 students)
small_districts <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  mutate(total = calc_total(.)) %>%
  filter(total > 0, total < 5000)

# Size distribution
ggplot(small_districts, aes(x = total)) +
  geom_histogram(binwidth = 500, fill = colors["total"], color = "white") +
  labs(title = "Small District Size Distribution",
       subtitle = paste(nrow(small_districts), "districts serve fewer than 5,000 students each"),
       x = "Students", y = "Number of Districts") +
  theme_readme()

## ----english-learners---------------------------------------------------------
# Get LEP data for current year
lep_df <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  mutate(
    lep_pct = suppressWarnings(as.numeric(get_pct_col(., "lep"))),
    total = calc_total(.)
  ) %>%
  filter(!is.na(lep_pct), total > 0) %>%
  arrange(desc(lep_pct)) %>%
  head(15) %>%
  mutate(district_label = reorder(SCHOOL_DSTRCT_NM, lep_pct))

ggplot(lep_df, aes(x = district_label, y = lep_pct)) +
  geom_col(fill = colors["hispanic"]) +
  coord_flip() +
  labs(title = "Districts with Highest English Learner Populations",
       subtitle = "Percent of students classified as Limited English Proficient",
       x = "", y = "Percent EL") +
  theme_readme()

## ----charter-growth-----------------------------------------------------------
# State charter schools identified by name patterns
charter_schools <- enr_current %>%
  filter(DETAIL_LVL_DESC == "School",
         grepl("Charter|Academy|KIPP|Ivy Prep", INSTN_NAME, ignore.case = TRUE)) %>%
  mutate(total = calc_total(.)) %>%
  filter(total > 0) %>%
  arrange(desc(total)) %>%
  head(15) %>%
  mutate(school_label = reorder(INSTN_NAME, total))

ggplot(charter_schools, aes(x = school_label, y = total)) +
  geom_col(fill = colors["total"]) +
  coord_flip() +
  scale_y_continuous(labels = comma) +
  labs(title = "Largest Charter Schools in Georgia",
       subtitle = "Top 15 charter and academy schools by enrollment",
       x = "", y = "Students") +
  theme_readme()

## ----clayton-demographics-----------------------------------------------------
# Get racial composition of large districts
demo_districts <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  mutate(
    total = calc_total(.),
    black_pct = suppressWarnings(as.numeric(get_pct_col(., "black"))),
    white_pct = suppressWarnings(as.numeric(get_pct_col(., "white"))),
    hispanic_pct = suppressWarnings(as.numeric(get_pct_col(., "hispanic")))
  ) %>%
  filter(total > 20000) %>%
  arrange(desc(black_pct)) %>%
  head(10) %>%
  mutate(district_label = reorder(SCHOOL_DSTRCT_NM, black_pct))

ggplot(demo_districts, aes(x = district_label, y = black_pct)) +
  geom_col(fill = colors["black"]) +
  coord_flip() +
  labs(title = "Black Student Population by Large District",
       subtitle = "Districts with 20,000+ students",
       x = "", y = "Percent Black") +
  theme_readme()

## ----cobb-county--------------------------------------------------------------
# Metro Atlanta districts comparison
metro_codes <- c("667", "633", "644", "660", "631", "761")  # Gwinnett, Cobb, DeKalb, Fulton, Clayton, Atlanta

metro_df <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District", SCHOOL_DSTRCT_CD %in% metro_codes) %>%
  mutate(total = calc_total(.)) %>%
  arrange(desc(total)) %>%
  mutate(district_label = reorder(SCHOOL_DSTRCT_NM, total))

ggplot(metro_df, aes(x = district_label, y = total)) +
  geom_col(fill = colors["total"]) +
  coord_flip() +
  scale_y_continuous(labels = comma) +
  labs(title = "Metro Atlanta District Enrollment",
       subtitle = "The six largest districts in the Atlanta metro area",
       x = "", y = "Students") +
  theme_readme()

## ----savannah-chatham---------------------------------------------------------
# Non-Atlanta major districts
non_metro <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District",
         !SCHOOL_DSTRCT_CD %in% c("667", "633", "644", "660", "631", "761", "658", "675", "628", "710")) %>%
  mutate(total = calc_total(.)) %>%
  filter(total > 0) %>%
  arrange(desc(total)) %>%
  head(10) %>%
  mutate(district_label = reorder(SCHOOL_DSTRCT_NM, total))

ggplot(non_metro, aes(x = district_label, y = total)) +
  geom_col(fill = colors["total"]) +
  coord_flip() +
  scale_y_continuous(labels = comma) +
  labs(title = "Largest Districts Outside Metro Atlanta",
       subtitle = "Top 10 non-Atlanta metro districts",
       x = "", y = "Students") +
  theme_readme()

## ----econ-disadvantaged-------------------------------------------------------
# Get ED percentages by district
ed_df <- enr_current %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  mutate(
    total = calc_total(.),
    ed_pct = suppressWarnings(as.numeric(get_pct_col(., "ed")))
  ) %>%
  filter(!is.na(ed_pct), total > 10000) %>%
  arrange(desc(ed_pct)) %>%
  head(15) %>%
  mutate(district_label = reorder(SCHOOL_DSTRCT_NM, ed_pct))

ggplot(ed_df, aes(x = district_label, y = ed_pct)) +
  geom_col(fill = colors["total"]) +
  coord_flip() +
  geom_hline(yintercept = 64, linetype = "dashed", color = "red") +
  annotate("text", x = 7, y = 67, label = "State avg: 64%", color = "red", hjust = 0) +
  labs(title = "Economically Disadvantaged Students by District",
       subtitle = "Districts with 10,000+ students",
       x = "", y = "Percent Economically Disadvantaged") +
  theme_readme()

## ----gender-balance-----------------------------------------------------------
# State gender distribution
state_row <- enr_current %>% filter(DETAIL_LVL_DESC == "State")

male_pct <- suppressWarnings(as.numeric(get_pct_col(state_row, "male")))
female_pct <- suppressWarnings(as.numeric(get_pct_col(state_row, "female")))

gender_df <- data.frame(
  gender = c("Male", "Female"),
  pct = c(male_pct, female_pct)
)

ggplot(gender_df, aes(x = gender, y = pct, fill = gender)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = paste0(pct, "%")), vjust = -0.5, size = 6, fontface = "bold") +
  scale_fill_manual(values = c("Male" = "#3498DB", "Female" = "#E91E63")) +
  scale_y_continuous(limits = c(0, 60)) +
  labs(title = "Gender Distribution in Georgia Public Schools",
       subtitle = "Near-equal representation of male and female students",
       x = "", y = "Percent") +
  theme_readme() +
  theme(legend.position = "none")

