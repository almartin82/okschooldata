# ==============================================================================
# Graduation Rate LIVE Pipeline Tests
# ==============================================================================
#
# These tests verify the entire data pipeline using LIVE network calls.
# NO MOCKS - real HTTP requests to Georgia GOSA CSV downloads.
#
# Purpose: Detect breakages early when GOSA changes file locations.
#
# Test Categories:
#   1. URL Availability - HTTP 200 checks
#   2. File Download - Verify actual CSV retrieval
#   3. File Parsing - readr succeeds
#   4. Column Structure - Expected columns present
#   5. Year Filtering - Single year extraction works
#   6. Data Quality - No Inf/NaN, valid ranges
#   7. Aggregation - State/district/school levels exist
#   8: Output Fidelity - Verified test values match
#
# ==============================================================================

# Helper function for network skip guard
skip_if_offline <- function() {
  tryCatch({
    response <- httr::HEAD("https://www.google.com", httr::timeout(5))
    if (httr::http_error(response)) skip("No network connectivity")
  }, error = function(e) skip("No network connectivity"))
}

# ==============================================================================
# Test 1: URL Availability
# ==============================================================================

test_that("Georgia GOSA graduation rate CSV URL returns HTTP 200 (2023-24)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  response <- httr::HEAD(url, httr::timeout(30))

  expect_equal(httr::status_code(response), 200)
})

test_that("Georgia GOSA graduation rate CSV URL returns HTTP 200 (2022-23)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2023/Graduation_Rate_2022-23_2023-12-15_18_55_15.csv"

  response <- httr::HEAD(url, httr::timeout(30))

  expect_equal(httr::status_code(response), 200)
})

test_that("Georgia GOSA graduation rate CSV URL returns HTTP 200 (2021-22)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2022/Graduation_Rate_2022_Dec082022.csv"

  response <- httr::HEAD(url, httr::timeout(30))

  expect_equal(httr::status_code(response), 200)
})

# ==============================================================================
# Test 2: File Download
# ==============================================================================

test_that("Can download graduation rate CSV for 2023-24", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  response <- httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  expect_equal(httr::status_code(response), 200)

  # Verify file size is reasonable (should be ~2MB)
  file_size <- file.info(temp_file)$size
  expect_gt(file_size, 1000000)  # At least 1MB
})

test_that("Downloaded file is CSV, not HTML error page", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  response <- httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  expect_equal(httr::status_code(response), 200)

  # Read first line to verify it's CSV
  first_line <- readLines(temp_file, n = 1)

  # Should contain expected column names
  expect_true(grepl("LONG_SCHOOL_YEAR", first_line))
  expect_true(grepl("DETAIL_LVL_DESC", first_line))
  expect_true(grepl("PROGRAM_TOTAL", first_line))
})

test_that("Can download graduation rate CSV for historical year (2021-22)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2022/Graduation_Rate_2022_Dec082022.csv"

  response <- httr::GET(url, httr::timeout(60))

  expect_equal(httr::status_code(response), 200)

  # Verify content type
  content_type <- httr::headers(response)$`content-type`
  expect_true(grepl("text/csv|text/plain", content_type))
})

# ==============================================================================
# Test 3: File Parsing
# ==============================================================================

test_that("Can parse CSV with readr", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  expect_true(is.data.frame(data))
  expect_gt(nrow(data), 10000)
})

test_that("Parsed data has correct column structure", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Check for expected columns
  expected_cols <- c("LONG_SCHOOL_YEAR", "DETAIL_LVL_DESC", "SCHOOL_DSTRCT_CD",
                     "SCHOOL_DSTRCT_NM", "INSTN_NUMBER", "INSTN_NAME",
                     "GRADES_SERVED_DESC", "LABEL_LVL_1_DESC",
                     "PROGRAM_TOTAL", "PROGRAM_PERCENT", "TOTAL_COUNT")

  expect_true(all(expected_cols %in% names(data)))
})

test_that("Can parse data from different years", {
  skip_if_offline()

  # Test multiple years to ensure schema consistency
  years_to_test <- list(
    "2023-24" = "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv",
    "2022-23" = "https://download.gosa.ga.gov/2023/Graduation_Rate_2022-23_2023-12-15_18_55_15.csv",
    "2021-22" = "https://download.gosa.ga.gov/2022/Graduation_Rate_2022_Dec082022.csv"
  )

  for (year_name in names(years_to_test)) {
    temp_file <- tempfile(fileext = ".csv")
    httr::GET(years_to_test[[year_name]], httr::timeout(60),
              httr::write_disk(temp_file, overwrite = TRUE))

    data <- readr::read_csv(temp_file, show_col_types = FALSE)

    expect_true(is.data.frame(data))
    expect_gt(nrow(data), 0)
  }
})

# ==============================================================================
# Test 4: Column Structure
# ==============================================================================

test_that("CSV has expected column names", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  expected_cols <- c("LONG_SCHOOL_YEAR", "DETAIL_LVL_DESC", "SCHOOL_DSTRCT_CD",
                     "SCHOOL_DSTRCT_NM", "INSTN_NUMBER", "INSTN_NAME",
                     "GRADES_SERVED_DESC", "LABEL_LVL_1_DESC",
                     "PROGRAM_TOTAL", "PROGRAM_PERCENT", "TOTAL_COUNT")

  expect_true(all(expected_cols %in% names(data)))
})

test_that("Column data types are consistent", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Check string columns
  expect_true(is.character(data$LONG_SCHOOL_YEAR))
  expect_true(is.character(data$DETAIL_LVL_DESC))
  expect_true(is.character(data$SCHOOL_DSTRCT_CD))

  # Numeric columns come as strings (need conversion)
  expect_true(is.character(data$PROGRAM_TOTAL))
  expect_true(is.character(data$PROGRAM_PERCENT))
})

test_that("State record exists in data", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  state_records <- data[data$DETAIL_LVL_DESC == "State", ]

  expect_gt(nrow(state_records), 0)
})

# ==============================================================================
# Test 5: Year Filtering
# ==============================================================================

test_that("Can extract data for single year (2023-24)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # All records should have LONG_SCHOOL_YEAR = "2023-24"
  expect_true(all(data$LONG_SCHOOL_YEAR == "2023-24"))
})

test_that("School year format is consistent", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Should be in format "YYYY-YY"
  expect_true(all(grepl("^\\d{4}-\\d{2}$", data$LONG_SCHOOL_YEAR)))
})

# ==============================================================================
# Test 6: Data Quality
# ==============================================================================

test_that("No negative graduation percentages after conversion", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Convert PROGRAM_PERCENT to numeric (excluding "TFS" values)
  grad_pct <- as.numeric(data$PROGRAM_PERCENT)

  expect_true(all(grad_pct >= 0 | is.na(grad_pct), na.rm = TRUE))
})

test_that("Graduation percentages are in valid range (0-100)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Convert PROGRAM_PERCENT to numeric (GA uses whole numbers like 93.75, not decimals)
  grad_pct <- as.numeric(data$PROGRAM_PERCENT)

  expect_true(all(grad_pct >= 0 & grad_pct <= 100 | is.na(grad_pct), na.rm = TRUE))
})

test_that("Cohort counts are non-negative", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Convert TOTAL_COUNT to integer
  cohort_cnt <- as.integer(data$TOTAL_COUNT)

  expect_true(all(cohort_cnt >= 0 | is.na(cohort_cnt), na.rm = TRUE))
})

test_that("No duplicate records", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Create unique key
  data$key <- paste(data$LONG_SCHOOL_YEAR, data$DETAIL_LVL_DESC,
                   data$SCHOOL_DSTRCT_CD, data$INSTN_NUMBER,
                   data$LABEL_LVL_1_DESC, sep = "_")

  expect_equal(nrow(data), length(unique(data$key)))
})

# ==============================================================================
# Test 7: Aggregation
# ==============================================================================

test_that("State record has all expected subgroups", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  state_data <- data[data$DETAIL_LVL_DESC == "State", ]

  subgroups <- unique(state_data$LABEL_LVL_1_DESC)

  # Should have at least 18 subgroups
  expect_gte(length(subgroups), 18)
})

test_that("District records exist", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  district_data <- data[data$DETAIL_LVL_DESC == "District", ]

  expect_gt(nrow(district_data), 0)

  # Should have ~180+ districts in GA
  unique_districts <- length(unique(district_data$SCHOOL_DSTRCT_CD))
  expect_gte(unique_districts, 150)
})

test_that("School records exist", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  school_data <- data[data$DETAIL_LVL_DESC == "School", ]

  expect_gt(nrow(school_data), 0)
})

test_that("TFS (Too Few Students) values exist for small subgroups", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # Should have some "TFS" values (data suppression for small cohorts)
  tfs_count <- sum(data$PROGRAM_TOTAL == "TFS", na.rm = TRUE)

  expect_gt(tfs_count, 0)
})

# ==============================================================================
# Test 8: Output Fidelity
# ==============================================================================

test_that("State-level graduation rate is reasonable", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  state_record <- data[data$DETAIL_LVL_DESC == "State" &
                       data$LABEL_LVL_1_DESC == "Grad Rate -ALL Students", ]

  grad_pct <- as.numeric(state_record$PROGRAM_PERCENT)

  # GA state graduation rate should be ~80-90%
  expect_gte(grad_pct, 80)
  expect_lte(grad_pct, 95)
})

test_that("State cohort size is substantial", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  state_record <- data[data$DETAIL_LVL_DESC == "State" &
                       data$LABEL_LVL_1_DESC == "Grad Rate -ALL Students", ]

  cohort_size <- as.integer(state_record$TOTAL_COUNT)

  # GA should have ~100K+ students in cohort
  expect_gte(cohort_size, 100000)
})

test_that("Appling County data exists (district 601)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  appling_data <- data[data$SCHOOL_DSTRCT_CD == "601" &
                       data$DETAIL_LVL_DESC == "District" &
                       data$LABEL_LVL_1_DESC == "Grad Rate -ALL Students", ]

  expect_gt(nrow(appling_data), 0)

  # Appling County should have reasonable graduation rate
  grad_pct <- as.numeric(appling_data$PROGRAM_PERCENT)
  expect_gte(grad_pct, 70)
  expect_lte(grad_pct, 100)
})

test_that("Appling County High School data exists (school 0103)", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  appling_hs <- data[data$SCHOOL_DSTRCT_CD == "601" &
                     data$INSTN_NUMBER == "0103" &
                     data$DETAIL_LVL_DESC == "School" &
                     data$LABEL_LVL_1_DESC == "Grad Rate -ALL Students", ]

  expect_gt(nrow(appling_hs), 0)

  # Should have reasonable cohort size (200-300 students)
  cohort_size <- as.integer(appling_hs$TOTAL_COUNT)
  expect_gte(cohort_size, 100)
  expect_lte(cohort_size, 500)
})

test_that("Verified test values match raw CSV data", {
  skip_if_offline()

  url <- "https://download.gosa.ga.gov/2024/Graduation_Rate_2023-24_2025-01-14_16_53_10.csv"

  temp_file <- tempfile(fileext = ".csv")
  httr::GET(url, httr::timeout(60), httr::write_disk(temp_file, overwrite = TRUE))

  data <- readr::read_csv(temp_file, show_col_types = FALSE)

  # State-level: ALL Students (verified manually)
  # Expected: 117,661 graduates / 137,710 cohort = 85.44%
  state_all <- data[data$DETAIL_LVL_DESC == "State" &
                    data$LABEL_LVL_1_DESC == "Grad Rate -ALL Students", ]

  expect_equal(as.integer(state_all$PROGRAM_TOTAL), 117661)
  expect_equal(as.integer(state_all$TOTAL_COUNT), 137710)
  expect_equal(round(as.numeric(state_all$PROGRAM_PERCENT), 2), 85.44)

  # Appling County: ALL Students (verified manually)
  # Expected: 225 graduates / 240 cohort = 93.75%
  appling_all <- data[data$SCHOOL_DSTRCT_CD == "601" &
                      data$DETAIL_LVL_DESC == "District" &
                      data$LABEL_LVL_1_DESC == "Grad Rate -ALL Students", ]

  expect_equal(as.integer(appling_all$PROGRAM_TOTAL), 225)
  expect_equal(as.integer(appling_all$TOTAL_COUNT), 240)
  expect_equal(round(as.numeric(appling_all$PROGRAM_PERCENT), 2), 93.75)
})
