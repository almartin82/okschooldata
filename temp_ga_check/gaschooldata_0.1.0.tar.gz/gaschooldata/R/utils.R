# ==============================================================================
# Utility Functions
# ==============================================================================

#' @importFrom rlang .data
NULL

#' Safely convert to numeric, handling special values
#'
#' Converts input to numeric, handling "TFS" (Too Few Students) and other
#' non-numeric values by converting them to NA.
#'
#' @param x Vector to convert
#' @return Numeric vector with NA for non-convertible values
#' @keywords internal
safe_numeric <- function(x) {
  x <- as.character(x)
  x[x == "TFS"] <- NA
  x[x == "N/A"] <- NA
  x[x == "*"] <- NA
  x[x == "-"] <- NA
  as.numeric(x)
}

globalVariables(c("type", "row_total", "n_students"))
