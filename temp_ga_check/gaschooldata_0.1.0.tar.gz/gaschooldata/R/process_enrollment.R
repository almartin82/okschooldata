# ==============================================================================
# Enrollment Data Processing Functions
# ==============================================================================
#
# This file contains functions for processing raw GOSA enrollment data into a
# clean, standardized format.
#
# ==============================================================================

#' Process raw GOSA enrollment data
#'
#' Transforms raw GOSA data into a standardized schema.
#'
#' @param raw_data List from get_raw_enr
#' @param end_year School year end
#' @return Processed data frame with standardized columns
#' @keywords internal
process_enr <- function(raw_data, end_year) {

  df <- raw_data$enrollment 
n_rows <- nrow(df) 
result <- data.frame(end_year = rep(end_year, n_rows), stringsAsFactors = FALSE) 
result$type <- ifelse(df$DETAIL_LVL_DESC == "School", "Campus", df$DETAIL_LVL_DESC) 
result$district_id <- ifelse(df$SCHOOL_DSTRCT_CD == "ALL", NA, df$SCHOOL_DSTRCT_CD) 
result$campus_id <- ifelse(df$INSTN_NUMBER == "ALL", NA, df$INSTN_NUMBER) 
result$district_name <- ifelse(df$SCHOOL_DSTRCT_NM == "All Column Values" | is.na(df$SCHOOL_DSTRCT_NM), NA, trimws(df$SCHOOL_DSTRCT_NM)) 
result$campus_name <- ifelse(df$INSTN_NAME == "All Column Values" | is.na(df$INSTN_NAME), NA, trimws(df$INSTN_NAME)) 
grade_cols <- grep("^GRADE_", names(df), value = TRUE) 
if (length(grade_cols) > 0) {
    result$row_total <- rowSums(df[, grade_cols, drop = FALSE], na.rm = TRUE)
} else {
    if ("ENROLL_COUNT_SPECIAL_ED_K12" %in% names(df)) {
        result$row_total <- safe_numeric(df$ENROLL_COUNT_SPECIAL_ED_K12)/safe_numeric(df$ENROLL_PCT_SPECIAL_ED_K12) * 100
    }
    else {
        result$row_total <- NA
    }
} 
demo_pct_map <- list(asian = "ENROLL_PCT_ASIAN", native_american = "ENROLL_PCT_NATIVE", black = "ENROLL_PCT_BLACK", hispanic = "ENROLL_PCT_HISPANIC", multiracial = "ENROLL_PCT_MULTIRACIAL", white = "ENROLL_PCT_WHITE") 
for (col_name in names(demo_pct_map)) {
    gosa_col <- demo_pct_map[[col_name]]
    if (gosa_col %in% names(df)) {
        pct <- safe_numeric(df[[gosa_col]])
        result[[col_name]] <- (pct/100) * result$row_total
    }
} 
if ("ENROLL_PCT_MALE" %in% names(df)) {
    pct_male <- safe_numeric(df$ENROLL_PCT_MALE)
    result$male <- (pct_male/100) * result$row_total
} 
if ("ENROLL_PCT_FEMALE" %in% names(df)) {
    pct_female <- safe_numeric(df$ENROLL_PCT_FEMALE)
    result$female <- (pct_female/100) * result$row_total
} 
if ("ENROLL_PCT_ED" %in% names(df)) {
    pct_ed <- safe_numeric(df$ENROLL_PCT_ED)
    result$econ_disadv <- (pct_ed/100) * result$row_total
} 
if ("ENROLL_COUNT_ESOL" %in% names(df)) {
    result$lep <- safe_numeric(df$ENROLL_COUNT_ESOL)
} else if ("ENROLL_PCT_LEP" %in% names(df)) {
    pct_lep <- safe_numeric(df$ENROLL_PCT_LEP)
    result$lep <- (pct_lep/100) * result$row_total
} 
if ("ENROLL_COUNT_SPECIAL_ED_K12" %in% names(df)) {
    result$special_ed <- safe_numeric(df$ENROLL_COUNT_SPECIAL_ED_K12)
} else if ("ENROLL_PCT_SWD" %in% names(df)) {
    pct_swd <- safe_numeric(df$ENROLL_PCT_SWD)
    result$special_ed <- (pct_swd/100) * result$row_total
} 
grade_map <- list(grade_pk = "GRADE_PK", grade_k = "GRADE_K", grade_01 = "GRADE_1st", grade_02 = "GRADE_2nd", grade_03 = "GRADE_3rd", grade_04 = "GRADE_4th", grade_05 = "GRADE_5th", grade_06 = "GRADE_6th", grade_07 = "GRADE_7th", grade_08 = "GRADE_8th", grade_09 = "GRADE_9th", grade_10 = "GRADE_10th", grade_11 = "GRADE_11th", grade_12 = "GRADE_12th") 
for (col_name in names(grade_map)) {
    gosa_col <- grade_map[[col_name]]
    if (gosa_col %in% names(df)) {
        result[[col_name]] <- safe_numeric(df[[gosa_col]])
    }
} 
numeric_cols <- c("row_total", "male", "female", "asian", "native_american", "black", "hispanic", "multiracial", "white", "econ_disadv", "lep", "special_ed", "grade_pk", "grade_k", "grade_01", "grade_02", "grade_03", "grade_04", "grade_05", "grade_06", "grade_07", "grade_08", "grade_09", "grade_10", "grade_11", "grade_12") 
for (col in numeric_cols) {
    if (col %in% names(result)) {
        result[[col]] <- as.numeric(result[[col]])
    }
} 
result
}
