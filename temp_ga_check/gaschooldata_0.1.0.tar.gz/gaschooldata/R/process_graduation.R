# ==============================================================================
# Process Graduation Rate Data - Convert raw CSV to standard format
# ==============================================================================
#
# This file contains functions for processing raw graduation rate data from
# GOSA CSV format into a standardized intermediate format.
#
# Processing steps:
#   1. Convert string columns to numeric
#   2. Handle "TFS" (Too Few Students) suppression values
#   3. Extract subgroup names from LABEL_LVL_1_DESC
#   4. Add level categorization (state/district/school)
#   5. Convert school year to end_year
#
# ==============================================================================

#' Process raw graduation data
#'
#' Converts raw GOSA CSV data to a standardized intermediate format.
#' Handles type conversions, suppressed values, and subgroup extraction.
#'
#' @param raw_data Raw data frame from get_raw_graduation()
#' @return Data frame with processed graduation data
#' @keywords internal
process_graduation <- function(raw_data) {

  # Standardize column names
  data <- raw_data

  # Extract end_year from LONG_SCHOOL_YEAR (e.g., "2023-24" -> 2024)
  data$sy_end <- as.integer(substr(data$LONG_SCHOOL_YEAR, 1, 4)) + 1

  # Convert numeric columns (handle "TFS" as NA)
  data$program_total <- as.integer(data$PROGRAM_TOTAL)
  data$program_total[data$PROGRAM_TOTAL == "TFS"] <- NA_integer_

  data$program_percent <- as.numeric(data$PROGRAM_PERCENT)
  data$program_percent[data$PROGRAM_PERCENT == "TFS"] <- NA_real_

  data$cohort_size <- as.integer(data$TOTAL_COUNT)
  data$cohort_size[data$TOTAL_COUNT == "TFS"] <- NA_integer_

  # Extract subgroup from LABEL_LVL_1_DESC (remove "Grad Rate -" prefix)
  data$subgroup <- gsub("^Grad Rate -", "", data$LABEL_LVL_1_DESC)

  # Normalize level names
  data$level <- data$DETAIL_LVL_DESC

  # Clean up district and school codes
  data$district_code <- data$SCHOOL_DSTRCT_CD
  data$school_code <- data$INSTN_NUMBER

  # For state level, set district_code to "ALL"
  data$district_code[data$level == "State"] <- "ALL"

  # For district level, set school_code to "ALL"
  data$school_code[data$level == "District"] <- "ALL"

  # For state level, set school_code to "ALL"
  data$school_code[data$level == "State"] <- "ALL"

  # Select and rename columns for standardized format
  processed <- data %>%
    dplyr::select(
      end_year = sy_end,
      level,
      district_code,
      school_code,
      district_name = SCHOOL_DSTRCT_NM,
      school_name = INSTN_NAME,
      subgroup,
      n_graduates = program_total,
      grad_rate = program_percent,
      cohort_size
    ) %>%
    dplyr::mutate(
      # Convert grad rate from percentage to decimal (GA uses whole numbers like 93.75)
      grad_rate = grad_rate / 100
    )

  processed
}

#' Validate processed graduation data
#'
#' Performs data quality checks on processed graduation data.
#'
#' @param data Processed data frame from process_graduation()
#' @return Invisible TRUE if validation passes, otherwise throws error
#' @keywords internal
validate_graduation <- function(data) {

  # Check for required columns
  required_cols <- c("end_year", "level", "district_code", "school_code",
                     "subgroup", "n_graduates", "grad_rate", "cohort_size")

  missing_cols <- setdiff(required_cols, names(data))
  if (length(missing_cols) > 0) {
    stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
  }

  # Check graduation rate range
  if (any(data$grad_rate < 0 | data$grad_rate > 1, na.rm = TRUE)) {
    stop("Graduation rates must be between 0 and 1 (as decimals)")
  }

  # Check for negative cohort sizes
  if (any(data$cohort_size < 0, na.rm = TRUE)) {
    stop("Cohort sizes cannot be negative")
  }

  # Check for negative graduate counts
  if (any(data$n_graduates < 0, na.rm = TRUE)) {
    stop("Graduate counts cannot be negative")
  }

  # Check that n_graduates <= cohort_size
  if (any(data$n_graduates > data$cohort_size, na.rm = TRUE)) {
    warning("Some records have more graduates than cohort size (possible data error)")
  }

  invisible(TRUE)
}
