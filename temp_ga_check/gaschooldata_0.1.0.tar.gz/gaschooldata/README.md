# gaschooldata

<!-- badges: start -->
[![R-CMD-check](https://github.com/almartin82/gaschooldata/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/almartin82/gaschooldata/actions/workflows/R-CMD-check.yaml)
[![Python Tests](https://github.com/almartin82/gaschooldata/actions/workflows/python-test.yaml/badge.svg)](https://github.com/almartin82/gaschooldata/actions/workflows/python-test.yaml)
[![pkgdown](https://github.com/almartin82/gaschooldata/actions/workflows/pkgdown.yaml/badge.svg)](https://github.com/almartin82/gaschooldata/actions/workflows/pkgdown.yaml)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

**[Documentation](https://almartin82.github.io/gaschooldata/)** | **[Getting Started](https://almartin82.github.io/gaschooldata/articles/quickstart.html)** | **[Enrollment Trends](https://almartin82.github.io/gaschooldata/articles/enrollment-trends.html)**

Fetch and analyze Georgia school enrollment data from the Governor's Office of Student Achievement (GOSA) in R or Python.

## What can you find with gaschooldata?

**14 years of enrollment data (2011-2024).** 1.7 million students today. Over 180 districts. Here are fifteen stories hiding in the numbers - see the [Enrollment Trends](https://almartin82.github.io/gaschooldata/articles/enrollment-trends.html) vignette for interactive visualizations:

---

### 1. Georgia keeps growing

Georgia's public schools serve nearly 1.7 million students, making it the 8th largest school system in the nation.

```r
library(gaschooldata)
library(dplyr)

enr_2024 <- fetch_enr(2024)

# Calculate total from grade columns
grade_cols <- grep("^GRADE_", names(enr_2024), value = TRUE)
state <- enr_2024 %>% filter(DETAIL_LVL_DESC == "State")
total <- sum(sapply(grade_cols, function(col) as.numeric(state[[col]])), na.rm = TRUE)
cat("Total enrollment:", format(total, big.mark = ","))
#> Total enrollment: 1,699,690
```

![State growth](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/state-growth-1.png)

---

### 2. Hispanic population surge

Hispanic students have grown from 14% to 19% of Georgia's student population in just 10 years.

```r
enr <- fetch_enr_multi(c(2015, 2024))

enr %>%
  filter(DETAIL_LVL_DESC == "State") %>%
  select(end_year, starts_with("ENROLL_P")) %>%
  select(end_year, matches("HISPANIC"))
#> 2015: 14%
#> 2024: 19%
```

![Hispanic growth](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/hispanic-growth-1.png)

---

### 3. COVID hit kindergarten hardest

Kindergarten enrollment dropped sharply during the pandemic and hasn't fully recovered.

```r
enr_2024 <- fetch_enr(2024)

state <- enr_2024 %>% filter(DETAIL_LVL_DESC == "State")
cat("Kindergarten:", format(as.numeric(state$GRADE_K), big.mark = ","))
cat("vs 1st grade:", format(as.numeric(state$GRADE_1st), big.mark = ","))
#> Kindergarten: 118,820
#> vs 1st grade: 124,922
```

![COVID kindergarten](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/covid-kindergarten-1.png)

---

### 4. Georgia demographics transformation

White students have declined from 42% to 35% while Hispanic and multiracial students have increased.

```r
enr <- fetch_enr_multi(c(2015, 2024))

enr %>%
  filter(DETAIL_LVL_DESC == "State") %>%
  select(end_year, matches("WHITE|BLACK|HISPANIC"))
```

![Demographics shift](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/demographics-shift-1.png)

---

### 5. Suburban Atlanta growth

Forsyth County has nearly doubled in size, while Cherokee and Henry counties have grown rapidly.

```r
enr_2024 <- fetch_enr(2024)

# Forsyth, Cherokee, Henry
suburban <- enr_2024 %>%
  filter(SCHOOL_DSTRCT_CD %in% c("658", "628", "675"),
         DETAIL_LVL_DESC == "District") %>%
  select(SCHOOL_DSTRCT_NM)
```

![Suburban growth](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/suburban-growth-1.png)

---

### 6. Gwinnett County is Georgia's school system giant

Gwinnett County serves over 180,000 students, making it the largest district in Georgia and one of the largest in the nation.

```r
enr_2024 <- fetch_enr(2024)

# Calculate district totals
grade_cols <- grep("^GRADE_", names(enr_2024), value = TRUE)
districts <- enr_2024 %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  rowwise() %>%
  mutate(total = sum(c_across(all_of(grade_cols)) %>% as.numeric(), na.rm = TRUE)) %>%
  arrange(desc(total)) %>%
  head(5) %>%
  select(SCHOOL_DSTRCT_NM, total)
```

![Gwinnett dominance](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/gwinnett-dominance-1.png)

---

### 7. Atlanta Public Schools is shrinking

Atlanta Public Schools has declined from over 50,000 to around 48,000 students as families move to suburbs.

```r
enr_2024 <- fetch_enr(2024)

atlanta <- enr_2024 %>%
  filter(SCHOOL_DSTRCT_CD == "761", DETAIL_LVL_DESC == "District")

cat("Atlanta Public Schools enrollment:",
    format(sum(as.numeric(atlanta$GRADE_K), as.numeric(atlanta$GRADE_1st),
               as.numeric(atlanta$GRADE_2nd), as.numeric(atlanta$GRADE_3rd),
               as.numeric(atlanta$GRADE_4th), as.numeric(atlanta$GRADE_5th),
               as.numeric(atlanta$GRADE_6th), as.numeric(atlanta$GRADE_7th),
               as.numeric(atlanta$GRADE_8th), as.numeric(atlanta$GRADE_9th),
               as.numeric(atlanta$GRADE_10th), as.numeric(atlanta$GRADE_11th),
               as.numeric(atlanta$GRADE_12th), na.rm = TRUE), big.mark = ","))
```

![Atlanta decline](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/atlanta-decline-1.png)

---

### 8. Rural Georgia is emptying out

Small rural districts are losing students as families move to metro Atlanta. Over 100 districts serve fewer than 5,000 students each.

```r
enr_2024 <- fetch_enr(2024)

grade_cols <- grep("^GRADE_", names(enr_2024), value = TRUE)
small_districts <- enr_2024 %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  rowwise() %>%
  mutate(total = sum(c_across(all_of(grade_cols)) %>% as.numeric(), na.rm = TRUE)) %>%
  filter(total > 0, total < 5000)

cat("Districts with fewer than 5,000 students:", nrow(small_districts))
```

![Rural decline](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/rural-decline-1.png)

---

### 9. English Learners exceed 100,000

Over 12% of Georgia students are English Learners, with concentrations in metro Atlanta.

```r
enr_2024 <- fetch_enr(2024)

state <- enr_2024 %>% filter(DETAIL_LVL_DESC == "State")
cat("English Learner percentage:", state$ENROLL_PCT_LEP, "%")
#> English Learner percentage: 12%
```

![English learners](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/english-learners-1.png)

---

### 10. Charter school growth

Georgia has expanded charter school options, particularly in urban areas.

```r
enr_2024 <- fetch_enr(2024)

charter_schools <- enr_2024 %>%
  filter(DETAIL_LVL_DESC == "School",
         grepl("Charter|Academy|KIPP", INSTN_NAME, ignore.case = TRUE)) %>%
  nrow()

cat("Schools with 'Charter', 'Academy', or 'KIPP' in name:", charter_schools)
```

![Charter growth](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/charter-growth-1.png)

---

### 11. Clayton County majority-Black enrollment

Clayton County has one of the highest Black student populations in the state at 68%.

```r
enr_2024 <- fetch_enr(2024)

clayton <- enr_2024 %>%
  filter(SCHOOL_DSTRCT_CD == "631", DETAIL_LVL_DESC == "District")

cat("Clayton County Black student percentage:", clayton$ENROLL_PCT_BLACK, "%")
#> Clayton County Black student percentage: 68%
```

![Clayton demographics](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/clayton-demographics-1.png)

---

### 12. Cobb County second largest

Cobb County serves over 105,000 students and is more diverse than many suburban districts.

```r
enr_2024 <- fetch_enr(2024)

cobb <- enr_2024 %>%
  filter(SCHOOL_DSTRCT_CD == "633", DETAIL_LVL_DESC == "District") %>%
  select(SCHOOL_DSTRCT_NM, ENROLL_PCT_WHITE, ENROLL_PCT_BLACK, ENROLL_PCT_HISPANIC)
```

![Cobb County](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/cobb-county-1.png)

---

### 13. Savannah-Chatham serves coastal Georgia

Savannah-Chatham County is the largest district outside metro Atlanta with over 34,000 students.

```r
enr_2024 <- fetch_enr(2024)

savannah <- enr_2024 %>%
  filter(SCHOOL_DSTRCT_CD == "625", DETAIL_LVL_DESC == "District") %>%
  select(SCHOOL_DSTRCT_NM, ENROLL_PCT_BLACK, ENROLL_PCT_WHITE)
```

![Savannah Chatham](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/savannah-chatham-1.png)

---

### 14. Economically disadvantaged majority

64% of Georgia students are classified as economically disadvantaged.

```r
enr_2024 <- fetch_enr(2024)

state <- enr_2024 %>% filter(DETAIL_LVL_DESC == "State")
cat("Economically disadvantaged:", state$ENROLL_PCT_ED, "%")
#> Economically disadvantaged: 64%
```

![Econ disadvantaged](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/econ-disadvantaged-1.png)

---

### 15. Gender balance across the state

Georgia maintains near-equal gender distribution in public schools.

```r
enr_2024 <- fetch_enr(2024)

state <- enr_2024 %>% filter(DETAIL_LVL_DESC == "State")
cat("Male:", state$ENROLL_PCT_MALE, "% | Female:", state$ENROLL_PCT_FEMALE, "%")
```

![Gender balance](https://almartin82.github.io/gaschooldata/articles/enrollment-trends_files/figure-html/gender-balance-1.png)

---

## Installation

```r
# install.packages("remotes")
remotes::install_github("almartin82/gaschooldata")
```

## Quick start

### R

```r
library(gaschooldata)
library(dplyr)

# Fetch one year
enr_2024 <- fetch_enr(2024)

# Fetch multiple years
enr_recent <- fetch_enr_multi(2020:2024)

# State totals
enr_2024 %>%
  filter(DETAIL_LVL_DESC == "State")

# District breakdown
enr_2024 %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  select(SCHOOL_DSTRCT_NM, ENROLL_PCT_WHITE, ENROLL_PCT_BLACK, ENROLL_PCT_HISPANIC)

# Demographics by district
enr_2024 %>%
  filter(DETAIL_LVL_DESC == "District") %>%
  select(SCHOOL_DSTRCT_NM, ENROLL_PCT_WHITE, ENROLL_PCT_BLACK,
         ENROLL_PCT_HISPANIC, ENROLL_PCT_ASIAN)
```

### Python

```python
import pygaschooldata as ga

# See available years
years = ga.get_available_years()
print(f"Data available from {years['min_year']} to {years['max_year']}")

# Fetch one year
enr_2024 = ga.fetch_enr(2024)

# Fetch multiple years
enr_multi = ga.fetch_enr_multi([2020, 2021, 2022, 2023, 2024])

# State totals
state_total = enr_2024[enr_2024['DETAIL_LVL_DESC'] == 'State']

# District breakdown
districts = enr_2024[enr_2024['DETAIL_LVL_DESC'] == 'District']
```

## Data availability

| Years | Source | Aggregation Levels | Demographics | Notes |
|-------|--------|-------------------|--------------|-------|
| **2011-2024** | GOSA Downloadable Data | State, District, School | Race, Gender, Special Populations | Full demographic breakdowns |

### What's available

- **Levels:** State, district (~180), and school (~2,300)
- **Demographics:** White, Black, Hispanic, Asian, Native American, Pacific Islander, Multiracial
- **Special populations:** English Learners (LEP), Special Education, Economically Disadvantaged
- **Grade levels:** Pre-K through Grade 12 (grade data available for recent years)

### ID System

Georgia uses district and school codes:
- **District Code:** 3-digit code (e.g., 660 for Gwinnett County)
- **School Code:** 4-digit code within district

## Data source

Governor's Office of Student Achievement: [GOSA Downloadable Data](https://download.gosa.ga.gov/) | [Report Card](https://gosa.georgia.gov/)

## Part of the State Schooldata Project

A simple, consistent interface for accessing state-published school data in Python and R.

**All 50 state packages:** [github.com/almartin82](https://github.com/almartin82?tab=repositories&q=schooldata)

## Author

[Andy Martin](https://github.com/almartin82) (almartin@gmail.com)

## License

MIT
