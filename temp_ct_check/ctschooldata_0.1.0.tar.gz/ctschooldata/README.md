# ctschooldata

<!-- badges: start -->
[![R-CMD-check](https://github.com/almartin82/ctschooldata/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/almartin82/ctschooldata/actions/workflows/R-CMD-check.yaml)
[![Python Tests](https://github.com/almartin82/ctschooldata/actions/workflows/python-test.yaml/badge.svg)](https://github.com/almartin82/ctschooldata/actions/workflows/python-test.yaml)
[![pkgdown](https://github.com/almartin82/ctschooldata/actions/workflows/pkgdown.yaml/badge.svg)](https://github.com/almartin82/ctschooldata/actions/workflows/pkgdown.yaml)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

Fetch and analyze Connecticut school enrollment data from the Connecticut State Department of Education (CSDE) in R or Python.

**[Documentation](https://almartin82.github.io/ctschooldata/)** | **[Getting Started](https://almartin82.github.io/ctschooldata/articles/quickstart.html)**

## What can you find with ctschooldata?

**18 years of enrollment data (2007-2024).** District and school-level data for Connecticut's public education system.

### Important Data Limitations

The automated data source (CT Open Data Education Directory) provides:
- School and district organization information
- Grade-level offerings (binary flags: 0/1)
- **NOT actual enrollment counts**

For real enrollment data with demographics and student counts, you must manually export from [EdSight](https://public-edsight.ct.gov/Students/Enrollment-Dashboard/Public-School-Enrollment-Export) and use `import_local_enr()`.

## Installation

```r
# install.packages("remotes")
remotes::install_github("almartin82/ctschooldata")
```

## Quick Start

### R

```r
library(ctschooldata)
library(dplyr)

# Fetch one year
enr_2024 <- fetch_enr(2024)

# Fetch multiple years
enr_multi <- fetch_enr_multi(2020:2024)

# State totals
enr_2024 %>%
  filter(is_state, subgroup == "total_enrollment", grade_level == "TOTAL")

# District breakdown
enr_2024 %>%
  filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL") %>%
  arrange(desc(n_students))

# Demographics
enr_2024 %>%
  filter(is_state, grade_level == "TOTAL",
         subgroup %in% c("white", "hispanic", "black", "asian")) %>%
  select(subgroup, n_students, pct)
```

### Python

```python
import pyctschooldata as ct

# Fetch 2024 data (2024-25 school year)
enr = ct.fetch_enr(2024)

# Statewide total
total = enr[(enr['is_state']) & (enr['subgroup'] == 'total_enrollment') & (enr['grade_level'] == 'TOTAL')]['n_students'].sum()
print(f"{total:,} students")
#> ~500,000 students

# Get multiple years
enr_multi = ct.fetch_enr_multi([2020, 2021, 2022, 2023, 2024, 2024])

# Check available years
years = ct.get_available_years()
print(f"Data available: {years['min_year']}-{years['max_year']}")
#> Data available: 2007-2024
```

## Data availability

| Years | Source | Notes |
|-------|--------|-------|
| **2007-2024** | EdSight / CT Open Data | Full demographic and grade-level data |

Data is sourced from the Connecticut State Department of Education via EdSight and the CT Open Data portal.

### What's included

- **Levels:** State, district (~170), school (~1,000)
- **Demographics:** White, Black, Hispanic, Asian, American Indian, Pacific Islander, Two or More Races
- **Special populations:** English learners, free/reduced lunch, students with disabilities
- **Grade levels:** Pre-K through 12

### Caveats

- Some data may require manual export from EdSight
- Use `import_local_enr()` if automatic downloads fail

## Data source

Connecticut State Department of Education: [EdSight](https://public-edsight.ct.gov/)

## Part of the State Schooldata Project

A simple, consistent interface for accessing state-published school data in Python and R.

**All 50 state packages:** [github.com/almartin82](https://github.com/almartin82?tab=repositories&q=schooldata)

## Author

[Andy Martin](https://github.com/almartin82) (almartin@gmail.com)

## License

MIT
