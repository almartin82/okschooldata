# Read data from cache

Read data from cache

## Usage

``` r
read_cache(end_year, type)
```

## Arguments

- end_year:

  School year end

- type:

  Data type ("tidy" or "wide")

## Value

Cached data frame
