# Create empty enrollment data frame

Returns an empty data frame with the standard schema.

## Usage

``` r
create_empty_enrollment_df(end_year)
```

## Arguments

- end_year:

  School year end

## Value

Empty data frame with standard columns
