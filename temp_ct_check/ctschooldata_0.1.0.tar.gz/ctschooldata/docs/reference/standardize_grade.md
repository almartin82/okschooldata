# Standardize grade level values

Converts various grade representations to standard format.

## Usage

``` r
standardize_grade(grade)
```

## Arguments

- grade:

  Character vector of grade values

## Value

Character vector with standardized grade levels
