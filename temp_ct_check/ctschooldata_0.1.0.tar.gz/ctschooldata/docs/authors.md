# Authors and Citation

## Authors

- **Al Martin**. Author, maintainer.

## Citation

Source:
[`DESCRIPTION`](https://github.com/almartin82/ctschooldata/blob/HEAD/DESCRIPTION)

Martin A (2026). *ctschooldata: Connecticut School Data*. R package
version 0.1.0, <https://almartin82.github.io/ctschooldata>.

    @Manual{,
      title = {ctschooldata: Connecticut School Data},
      author = {Al Martin},
      year = {2026},
      note = {R package version 0.1.0},
      url = {https://almartin82.github.io/ctschooldata},
    }
