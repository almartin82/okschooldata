## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  fig.width = 7,
  fig.height = 4
)

## ----fetch-data, eval=FALSE---------------------------------------------------
# library(caschooldata)
# library(dplyr)
# 
# # Fetch 2024 enrollment data (2023-24 school year)
# enr <- fetch_enr(2024)
# 
# head(enr)

## ----years-example, eval=FALSE------------------------------------------------
# # Fetch the most recent year
# enr_2025 <- fetch_enr(2025)
# 
# # Fetch historical data
# enr_2020 <- fetch_enr(2020)
# 
# # Fetch all years for trend analysis
# enr_all <- fetch_enr_multi(2018:2025)

## ----tidy-format, eval=FALSE--------------------------------------------------
# # Default: tidy format
# enr_tidy <- fetch_enr(2024)
# names(enr_tidy)
# # Includes: grade_level, reporting_category, subgroup, n_students

## ----wide-format, eval=FALSE--------------------------------------------------
# # Wide format: one column per grade
# enr_wide <- fetch_enr(2024, tidy = FALSE)
# names(enr_wide)
# # Includes: grade_tk, grade_k, grade_01, ..., grade_12, total_enrollment

## ----multi-year, eval=FALSE---------------------------------------------------
# # Fetch 2024 and 2025 data
# all_years <- fetch_enr_multi(c(2024, 2025))
# 
# # Analyze enrollment trends
# all_years %>%
#   filter(is_state, subgroup == "total", grade_level == "TOTAL") %>%
#   select(end_year, n_students)

## ----agg-levels, eval=FALSE---------------------------------------------------
# # State-level totals
# state <- enr %>%
#   filter(agg_level == "T")
# # or equivalently:
# state <- enr %>%
#   filter(is_state)
# 
# # County-level (58 California counties)
# counties <- enr %>%
#   filter(is_county)
# 
# # District-level
# districts <- enr %>%
#   filter(is_district)
# 
# # School-level
# schools <- enr %>%
#   filter(is_school)

## ----subgroups, eval=FALSE----------------------------------------------------
# # View all available subgroups
# enr %>%
#   distinct(reporting_category, subgroup) %>%
#   arrange(reporting_category)

## ----grades, eval=FALSE-------------------------------------------------------
# # Available grade levels
# enr %>%
#   distinct(grade_level) %>%
#   arrange(grade_level)
# 
# # Filter to specific grades
# elementary <- enr %>%
#   filter(grade_level %in% c("TK", "K", "01", "02", "03", "04", "05"))
# 
# middle_school <- enr %>%
#   filter(grade_level %in% c("06", "07", "08"))
# 
# high_school <- enr %>%
#   filter(grade_level %in% c("09", "10", "11", "12"))

## ----top-districts, eval=FALSE------------------------------------------------
# library(caschooldata)
# library(dplyr)
# 
# enr <- fetch_enr(2024)
# 
# enr %>%
#   filter(is_district, subgroup == "total", grade_level == "TOTAL") %>%
#   arrange(desc(n_students)) %>%
#   select(district_name, county_name, n_students) %>%
#   head(10)

## ----county-analysis, eval=FALSE----------------------------------------------
# # Enrollment by county
# county_enrollment <- enr %>%
#   filter(is_county, subgroup == "total", grade_level == "TOTAL") %>%
#   arrange(desc(n_students)) %>%
#   select(county_name, n_students)
# 
# # Top 5 counties
# head(county_enrollment, 5)

## ----demographics, eval=FALSE-------------------------------------------------
# # State-level race/ethnicity breakdown
# enr %>%
#   filter(
#     is_state,
#     grade_level == "TOTAL",
#     grepl("^RE_", reporting_category)
#   ) %>%
#   mutate(pct = n_students / sum(n_students) * 100) %>%
#   select(subgroup, n_students, pct) %>%
#   arrange(desc(n_students))

## ----charter-comparison, eval=FALSE-------------------------------------------
# # State-level charter enrollment
# charter_comparison <- enr %>%
#   filter(is_state, subgroup == "total", grade_level == "TOTAL") %>%
#   group_by(charter_status) %>%
#   summarize(total_enrollment = sum(n_students, na.rm = TRUE))
# 
# charter_comparison

## ----grade-aggs, eval=FALSE---------------------------------------------------
# # Create K-8, HS, K-12 aggregations
# grade_bands <- enr_grade_aggs(enr)
# 
# # View state-level grade bands
# grade_bands %>%
#   filter(is_state) %>%
#   select(grade_level, n_students)

## ----cds-codes, eval=FALSE----------------------------------------------------
# # Parse a CDS code
# parse_cds_code("19647331932334")
# # Returns: list(county = "19", district = "64733", school = "1932334")
# 
# # Filter to a specific district using CDS pattern
# lausd <- enr %>%
#   filter(grepl("^1964733", cds_code), is_school)

## ----viz-counties, eval=FALSE-------------------------------------------------
# library(ggplot2)
# 
# enr <- fetch_enr(2024)
# 
# # Top 10 counties by enrollment
# top_counties <- enr %>%
#   filter(is_county, subgroup == "total", grade_level == "TOTAL") %>%
#   arrange(desc(n_students)) %>%
#   head(10)
# 
# ggplot(top_counties, aes(x = reorder(county_name, n_students), y = n_students)) +
#   geom_col(fill = "steelblue") +
#   coord_flip() +
#   scale_y_continuous(labels = scales::comma) +
#   labs(
#     title = "Top 10 California Counties by Enrollment",
#     subtitle = "2023-24 School Year",
#     x = NULL,
#     y = "Total Enrollment"
#   ) +
#   theme_minimal()

## ----viz-demographics, eval=FALSE---------------------------------------------
# library(ggplot2)
# 
# # Race/ethnicity pie chart data
# race_data <- enr %>%
#   filter(
#     is_state,
#     grade_level == "TOTAL",
#     grepl("^RE_", reporting_category)
#   ) %>%
#   mutate(pct = n_students / sum(n_students)) %>%
#   select(subgroup, n_students, pct)
# 
# ggplot(race_data, aes(x = "", y = pct, fill = subgroup)) +
#   geom_bar(stat = "identity", width = 1) +
#   coord_polar("y", start = 0) +
#   labs(title = "California Enrollment by Race/Ethnicity") +
#   theme_void() +
#   theme(legend.position = "right")

## ----viz-trend, eval=FALSE----------------------------------------------------
# library(ggplot2)
# 
# # Fetch multiple years
# all_years <- fetch_enr_multi(c(2024, 2025))
# 
# # State enrollment over time
# state_trend <- all_years %>%
#   filter(is_state, subgroup == "total", grade_level == "TOTAL")
# 
# ggplot(state_trend, aes(x = end_year, y = n_students)) +
#   geom_line(color = "steelblue", size = 1.5) +
#   geom_point(color = "steelblue", size = 3) +
#   scale_y_continuous(labels = scales::comma) +
#   labs(
#     title = "California K-12 Enrollment",
#     x = "School Year (End Year)",
#     y = "Total Enrollment"
#   ) +
#   theme_minimal()

## ----cache-management, eval=FALSE---------------------------------------------
# # Check what's cached
# cache_status()
# 
# # Clear cache for a specific year
# clear_enr_cache(2024)
# 
# # Force a fresh download (bypass cache)
# enr_fresh <- fetch_enr(2024, use_cache = FALSE)

