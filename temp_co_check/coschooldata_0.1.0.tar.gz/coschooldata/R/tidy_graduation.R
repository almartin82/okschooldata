# ==============================================================================
# Graduation Rate Data Tidying Functions
# ==============================================================================
#
# This file contains functions for transforming graduation data from intermediate
# format to long (tidy) format with validation.
#
# ==============================================================================

#' Tidy graduation data
#'
#' Transforms processed graduation data to ensure consistent long format.
#' Validates data quality and ensures all required columns are present.
#'
#' @param df A processed graduation data frame from process_graduation()
#' @return A long data frame of tidied graduation data
#' @keywords internal
tidy_graduation <- function(df) {

  # Ensure required columns exist
  required_cols <- c(
    "end_year", "type",
    "district_id", "district_name",
    "school_id", "school_name",
    "subgroup", "cohort_type",
    "cohort_count", "graduate_count", "grad_rate",
    "is_state", "is_district", "is_school"
  )

  missing_cols <- setdiff(required_cols, names(df))
  if (length(missing_cols) > 0) {
    stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
  }

  # Remove rows with NA subgroup (data quality issue)
  df <- df[!is.na(df$subgroup), ]

  # Remove rows with zero or negative graduation rates (data quality)
  df <- df[!is.na(df$grad_rate) & df$grad_rate >= 0 & df$grad_rate <= 1, ]

  # Remove rows with NA cohort_count (can't validate without it)
  df <- df[!is.na(df$cohort_count), ]

  # Ensure IDs are character type (preserve leading zeros)
  df$district_id <- as.character(df$district_id)
  df$school_id <- as.character(df$school_id)

  # Ensure numeric columns are correct type
  df$grad_rate <- as.numeric(df$grad_rate)
  df$cohort_count <- as.integer(df$cohort_count)
  df$graduate_count <- as.integer(df$graduate_count)

  # Check for Inf values (division errors)
  if (any(is.infinite(df$grad_rate))) {
    warning("Removed rows with infinite graduation rates")
    df <- df[!is.infinite(df$grad_rate), ]
  }

  # Validate that graduate_count doesn't exceed cohort_count
  if (any(df$graduate_count > df$cohort_count, na.rm = TRUE)) {
    warning("Some rows have graduate_count exceeding cohort_count - setting to NA")
    df$graduate_count[df$graduate_count > df$cohort_count] <- NA
  }

  # Ensure correct column order
  tidy_df <- df[, required_cols]

  tidy_df
}
