#' coschooldata: Fetch and Process Colorado School Data
#'
#' Downloads and processes school data from the Colorado Department of Education
#' (CDE). Provides functions for fetching enrollment data from the Student October
#' Count collection, graduation rate data, and transforming it into tidy format for analysis.
#'
#' @section Main functions:
#' \describe{
#'   \item{\code{\link{fetch_enr}}}{Fetch enrollment data for a school year}
#'   \item{\code{\link{fetch_enr_multi}}}{Fetch enrollment data for multiple years}
#'   \item{\code{\link{fetch_graduation}}}{Fetch graduation rate data for a school year}
#'   \item{\code{\link{fetch_graduation_multi}}}{Fetch graduation rate data for multiple years}
#'   \item{\code{\link{get_available_years}}}{Get available year range for data}
#' }
#'
#' @section ID System:
#' Colorado uses a hierarchical ID system:
#' \itemize{
#'   \item District IDs: 4 digits (e.g., 0880 = Denver County 1)
#'   \item School IDs: 4 digits (unique within district context)
#' }
#'
#' @section Data Sources:
#' Data is sourced from the Colorado Department of Education:
#' \itemize{
#'   \item Pupil Membership: \url{https://www.cde.state.co.us/cdereval/pupilcurrent}
#'   \item Graduation Rates: \url{https://www.cde.state.co.us/cdereval/gradratecurrent}
#'   \item Data Archive: \url{https://ed.cde.state.co.us/cdereval/pupilmembership-statistics}
#' }
#'
#' @section Data Availability:
#' The package currently supports years 2020-2025 for enrollment data and 2010-2024 for graduation rates.
#' Data comes from the Student October Count collection and AYG cohort data published by CDE.
#' Use \code{get_available_years()} to check the current available range.
#'
#' @docType package
#' @name coschooldata-package
#' @aliases coschooldata
#' @keywords internal
"_PACKAGE"

# Declare non-standard evaluation variables for dplyr
utils::globalVariables(c(
  "district_id", "school_id", "type", "subgroup",
  "grad_rate", "cohort_count", "graduate_count",
  "is_state", "is_district", "is_school",
  "gender", "race_ethnicity", "end_year"
))
