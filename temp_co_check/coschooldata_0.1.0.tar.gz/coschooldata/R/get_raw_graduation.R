# ==============================================================================
# Raw Graduation Rate Data Download Functions
# ==============================================================================
#
# This file contains functions for downloading raw graduation rate data from the
# Colorado Department of Education (CDE).
#
# Data source: CDE Graduation/Completion Rate Excel Workbooks
# Available years: 2010-2024 (15 years)
#
# ==============================================================================

#' Base URL for CDE graduation data
#' @keywords internal
CDE_GRAD_BASE_URL <- "https://www.cde.state.co.us/cdereval"

#' Get available graduation years
#'
#' Returns a vector of years for which graduation rate data is available
#' from the Colorado Department of Education.
#'
#' @return Integer vector of years (2010-2024)
#' @export
#' @examples
#' \dontrun{
#' get_available_grad_years()
#' # Returns: 2010 2011 2012 ... 2024
#' }
get_available_grad_years <- function() {
  2010:2024
}

#' Download raw graduation data from CDE
#'
#' Downloads graduation rate data from the Colorado Department of Education.
#' Note: The primary CDE server (www.cde.state.co.us) is currently
#' experiencing connectivity issues. If downloads fail, the function will
#' provide guidance on alternative access methods.
#'
#' @param end_year School year end (2023-24 = 2024). Valid years: 2010-2024.
#' @return Data frame with graduation data including district and school records
#' @keywords internal
get_raw_graduation <- function(end_year) {

  # Validate year
  available_years <- get_available_grad_years()
  if (!end_year %in% available_years) {
    stop("end_year must be between ", min(available_years), " and ",
         max(available_years), ". Run get_available_grad_years() to see available years.")
  }

  message(paste("Downloading CDE graduation data for", end_year, "..."))

  # Build URL for graduation data workbook
  # CDE uses AYG (Anticipated Year of Graduation) naming convention
  url <- build_cde_grad_url(end_year)

  message(paste("  URL:", url))

  # Download with error handling
  response <- tryCatch({
    httr::GET(
      url,
      httr::write_disk(temp_file <- tempfile(fileext = ".xlsx"), overwrite = TRUE),
      httr::timeout(120),
      httr::config(ssl_verifypeer = FALSE)  # CDE has certificate issues
    )
  }, error = function(e) {
    if (file.exists(temp_file)) unlink(temp_file)
    stop(paste(
      "Failed to connect to CDE server:", e$message,
      "\n\nNOTE: The CDE server www.cde.state.co.us is experiencing connectivity issues.",
      "\nIf the server is down, you can:",
      "\n  1. Check https://ed.cde.state.co.us/cdereval/gradratecurrent for data availability",
      "\n  2. Download manually from the CDE website and use import_local_graduation()",
      "\n  3. Check server status at: https://www.cde.state.co.us"
    ))
  })

  if (httr::http_error(response)) {
    if (file.exists(temp_file)) unlink(temp_file)
    stop(paste(
      "HTTP error:", httr::status_code(response),
      "\nYear:", end_year,
      "\nURL:", url,
      "\n\nThe graduation data file may not be available for this year yet.",
      "\nCheck https://ed.cde.state.co.us/cdereval/gradratecurrent for release dates."
    ))
  }

  # Check file size (error pages are small)
  file_info <- file.info(temp_file)
  if (file_info$size < 5000) {
    unlink(temp_file)
    stop(paste(
      "Downloaded file too small (", file_info$size, " bytes).",
      "\nThis may indicate an error page or missing file.",
      "\nURL:", url
    ))
  }

  message(paste("  Downloaded", round(file_info$size / 1024, 1), "KB"))

  # Read Excel file
  raw_data <- tryCatch({
    # Read the district/school sheet with gender and race/ethnicity
    df <- readxl::read_excel(
      temp_file,
      sheet = "District and School Gender and 种族 Ethnicity",  # CDE uses Chinese character for "Race"
      col_types = "text"
    )

    unlink(temp_file)
    df

  }, error = function(e) {
    if (file.exists(temp_file)) unlink(temp_file)
    stop(paste("Failed to read Excel file:", e$message,
               "\nFile structure may have changed. Check CDE website."))
  })

  # Add end_year column
  raw_data$end_year <- end_year

  message(paste("  Extracted", nrow(raw_data), "records"))

  raw_data
}


#' Build CDE graduation data URL
#'
#' Constructs the URL for downloading graduation rate data from CDE.
#' Uses AYG (Anticipated Year of Graduation) cohort naming convention.
#'
#' @param end_year School year end
#' @return URL string
#' @keywords internal
build_cde_grad_url <- function(end_year) {

  # CDE uses Anticipated Year of Graduation (AYG) in filenames
  # The file contains graduation and completion rates by district and school,
  # broken down by gender and race/ethnicity

  ayg <- end_year  # AYG = end_year for 4-year rates

  # URL pattern based on CDE naming conventions:
  # AYG{year}GraduationCompletionDataSchoolGender种族ethnicity.xlsx
  # Note: CDE uses Chinese character "种族" for "Race" in filenames

  file_name <- paste0(
    "AYG", ayg,
    "GraduationCompletionDataSchoolGender种族ethnicity.xlsx"
  )

  paste0(CDE_GRAD_BASE_URL, "/", file_name)
}


#' Get local graduation data file
#'
#' Helper function to read a locally downloaded CDE graduation Excel file.
#' Use this when the CDE server is down or for testing purposes.
#'
#' @param file_path Path to local Excel file
#' @param end_year School year end
#' @return Data frame with graduation data
#' @export
#' @examples
#' \dontrun{
#' # Read manually downloaded file
#' grad <- import_local_graduation("~/Downloads/AYG2024GraduationCompletionDataSchoolGender种族ethnicity.xlsx", 2024)
#' }
import_local_graduation <- function(file_path, end_year) {

  if (!file.exists(file_path)) {
    stop("File not found: ", file_path)
  }

  message(paste("Reading local graduation data for", end_year, "..."))

  raw_data <- tryCatch({
    readxl::read_excel(
      file_path,
      sheet = "District and School Gender and 种族 Ethnicity",
      col_types = "text"
    )
  }, error = function(e) {
    stop(paste("Failed to read Excel file:", e$message))
  })

  raw_data$end_year <- end_year

  message(paste("  Extracted", nrow(raw_data), "records"))

  raw_data
}
