# ==============================================================================
# Graduation Rate Data Processing Functions
# ==============================================================================
#
# This file contains functions for processing raw graduation data from CDE
# into a standardized intermediate format.
#
# ==============================================================================

#' Process raw graduation data into standard schema
#'
#' Transforms raw CDE Excel data into the standardized schema used by
#' the package. Handles CDE's specific column naming conventions and
#' data structure.
#'
#' @param raw_data Data frame from get_raw_graduation()
#' @param end_year School year end
#' @return Processed data frame with standardized columns
#' @keywords internal
process_graduation <- function(raw_data, end_year) {

  # Helper to safely get a column value (handles missing columns)
  safe_col <- function(df, col_name) {
    if (col_name %in% names(df)) {
      return(df[[col_name]])
    }
    return(rep(NA_character_, nrow(df)))
  }

  # Helper to safely convert to numeric (handles NULL/NA/missing)
  safe_num <- function(x) {
    if (is.null(x) || length(x) == 0) return(NA_real_)
    x <- as.character(x)
    x[x == "" | x == "*" | x == "N/A" | tolower(x) == "na"] <- NA_character_
    suppressWarnings(as.numeric(x))
  }

  # CDE Excel file structure:
  # Columns typically include:
  # - Organization Code / District Code / School Code
  # - Organization Name / District Name / School Name
  # - Gender (Male, Female)
  # - Race/Ethnicity (various categories)
  # - Graduation Rate (percentage or decimal)
  # - Cohort Count
  # - Graduate Count

  # Extract and standardize columns
  # CDE uses various column names depending on year

  # Organization identifiers
  org_code <- safe_col(raw_data, "Organization Code")
  org_code <- ifelse(org_code == "" | is.na(org_code),
                     safe_col(raw_data, "District Code"),
                     org_code)

  org_name <- safe_col(raw_data, "Organization Name")
  org_name <- ifelse(org_name == "" | is.na(org_name),
                     safe_col(raw_data, "District Name"),
                     org_name)

  # School-specific fields (may be NA for district/state rows)
  school_code <- safe_col(raw_data, "School Code")
  school_name <- safe_col(raw_data, "School Name")

  # Subgroup columns
  gender <- safe_col(raw_data, "Gender")
  race_ethnicity <- safe_col(raw_data, "Race Ethnicity")
  race_ethnicity <- ifelse(race_ethnicity == "" | is.na(race_ethnicity),
                           safe_col(raw_data, "种族 Ethnicity"),
                           race_ethnicity)  # CDE uses Chinese characters

  # Graduation rate and counts
  grad_rate <- safe_num(safe_col(raw_data, "Graduation Rate"))
  cohort_count <- safe_num(safe_col(raw_data, "Cohort Count"))
  graduate_count <- safe_num(safe_col(raw_data, "Graduate Count"))

  # If graduate count missing, calculate from rate and cohort
  graduate_count <- ifelse(is.na(graduate_count) & !is.na(grad_rate) & !is.na(cohort_count),
                           round(cohort_count * grad_rate),
                           graduate_count)

  # Determine entity type
  # State rows have specific codes (usually "00" or "STATE")
  # District codes in CO are variable length
  # School codes are typically district + school

  is_state <- org_code == "00" |
              org_code == "STATE" |
              tolower(org_name) == "state" |
              tolower(org_name) == "colorado"

  type <- dplyr::if_else(is_state, "State",
                         dplyr::if_else(!is.na(school_code) & school_code != "", "School", "District"))

  # Build processed data frame
  processed <- data.frame(
    end_year = end_year,

    # Entity type
    type = type,

    # District information
    district_id = dplyr::if_else(type == "State", NA_character_,
                                 substr(org_code, 1, 4)),  # CO uses 4-digit district codes
    district_name = dplyr::if_else(type == "State", NA_character_, org_name),

    # School information
    school_id = dplyr::if_else(type == "School", as.character(school_code), NA_character_),
    school_name = dplyr::if_else(type == "School", school_name, NA_character_),

    # Subgroup
    # Combine gender and race/ethnicity into single subgroup field
    subgroup = dplyr::case_when(
      type == "State" & is.na(gender) & is.na(race_ethnicity) ~ "all",
      is.na(race_ethnicity) | race_ethnicity == "All Students" ~ tolower(gender),
      is.na(gender) | gender == "All" ~ tolower(race_ethnicity),
      TRUE ~ paste(tolower(gender), tolower(race_ethnicity), sep = "_")
    ),

    # Cohort type (CDE mainly reports 4-year rates)
    cohort_type = "4-year",  # Default to 4-year

    # Counts and rates
    cohort_count = as.integer(cohort_count),
    graduate_count = as.integer(graduate_count),

    # Graduation rate (convert from percentage to 0-1 scale if needed)
    grad_rate = dplyr::if_else(grad_rate > 1, grad_rate / 100, grad_rate),

    stringsAsFactors = FALSE
  )

  # Standardize subgroup names
  processed$subgroup <- dplyr::case_when(
    processed$subgroup == "all_students" ~ "all",
    processed$subgroup == "all" ~ "all",
    processed$subgroup == "male_all" | processed$subgroup == "male_all students" ~ "male",
    processed$subgroup == "female_all" | processed$subgroup == "female_all students" ~ "female",
    processed$subgroup == "all_white" ~ "white",
    processed$subgroup == "all_black or african american" ~ "black",
    processed$subgroup == "all_hispanic or latino" ~ "hispanic",
    processed$subgroup == "all_asian" ~ "asian",
    processed$subgroup == "all_american indian or alaska native" ~ "native_american",
    processed$subgroup == "all_native hawaiian or other pacific islander" ~ "pacific_islander",
    processed$subgroup == "all_two or more races" ~ "multiracial",
    is.na(processed$subgroup) ~ "all",  # Default to all if missing
    TRUE ~ processed$subgroup
  )

  # Remove rows with missing graduation rates (data quality)
  processed <- processed[!is.na(processed$grad_rate), ]

  # Add aggregation level flags
  processed$is_state <- processed$type == "State"
  processed$is_district <- processed$type == "District"
  processed$is_school <- processed$type == "School"

  processed
}
