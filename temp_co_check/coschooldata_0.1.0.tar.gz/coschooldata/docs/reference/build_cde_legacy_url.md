# Build CDE URL for legacy enrollment files (2009-2018)

Build CDE URL for legacy enrollment files (2009-2018)

## Usage

``` r
build_cde_legacy_url(end_year)
```

## Arguments

- end_year:

  School year end

## Value

URL string
