# Build cache file path for directory data

Build cache file path for directory data

## Usage

``` r
build_cache_path_directory(cache_type)
```

## Arguments

- cache_type:

  Type of cache ("directory_tidy" or "directory_raw")

## Value

File path string
