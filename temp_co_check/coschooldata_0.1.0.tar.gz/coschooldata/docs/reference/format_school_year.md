# Format end year as school year string

Format end year as school year string

## Usage

``` r
format_school_year(end_year)
```

## Arguments

- end_year:

  End year (e.g., 2024)

## Value

School year string (e.g., "2023-24")
