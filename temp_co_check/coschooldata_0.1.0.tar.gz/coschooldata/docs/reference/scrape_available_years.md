# Scrape CDE to discover all available years

Scrapes the CDE archive page to find all years for which enrollment data
is available.

## Usage

``` r
scrape_available_years()
```

## Value

Integer vector of available end years
