# Process district addresses data

Process district addresses data

## Usage

``` r
process_district_addresses(data)
```

## Arguments

- data:

  Raw district addresses data frame

## Value

Processed data frame
