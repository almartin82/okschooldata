# Clean and standardize text columns

Removes extra whitespace, converts to proper case, etc.

## Usage

``` r
clean_text(x)
```

## Arguments

- x:

  Character vector

## Value

Cleaned character vector
