# Process school addresses data

Process school addresses data

## Usage

``` r
process_school_addresses(data)
```

## Arguments

- data:

  Raw school addresses data frame

## Value

Processed data frame
