# Articles

### Key Insights

- [10 Insights from Colorado School Enrollment
  Data](https://almartin82.github.io/coschooldata/articles/enrollment_hooks.md):
