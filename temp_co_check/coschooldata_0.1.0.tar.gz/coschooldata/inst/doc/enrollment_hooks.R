## ----setup, include=FALSE-----------------------------------------------------
# Check if we're in a context where we should run live data fetches
NOT_CRAN <- identical(tolower(Sys.getenv("NOT_CRAN")), "true")

# Also check if we can actually fetch enrollment data
# The CDE data server (www.cde.state.co.us) may be down even when NOT_CRAN=true
can_fetch <- NOT_CRAN && tryCatch({
  # Quick connectivity check - try HEAD request first
  response <- httr::HEAD(
    "https://www.cde.state.co.us/cdereval/pupilmembership-statistics",
    httr::timeout(10)
  )
  !httr::http_error(response)
}, error = function(e) FALSE)

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE,
  fig.width = 8,
  fig.height = 5,
  eval = can_fetch
)

## ----load-packages------------------------------------------------------------
# library(coschooldata)
# library(dplyr)
# library(tidyr)
# library(ggplot2)
# 
# theme_set(theme_minimal(base_size = 14))

## ----statewide-trend----------------------------------------------------------
# enr <- fetch_enr_multi(2020:2024, use_cache = TRUE)
# 
# state_totals <- enr |>
#   filter(is_state, subgroup == "total_enrollment", grade_level == "TOTAL") |>
#   select(end_year, n_students) |>
#   mutate(change = n_students - lag(n_students),
#          pct_change = round(change / lag(n_students) * 100, 2))
# 
# state_totals

## ----statewide-chart----------------------------------------------------------
# ggplot(state_totals, aes(x = end_year, y = n_students)) +
#   geom_line(linewidth = 1.2, color = "#003366") +
#   geom_point(size = 3, color = "#003366") +
#   scale_y_continuous(labels = scales::comma) +
#   labs(
#     title = "Colorado Public School Enrollment (2020-2024)",
#     subtitle = "Growth has stalled after a decade of expansion",
#     x = "School Year (ending)",
#     y = "Total Enrollment"
#   )

## ----denver-decline-----------------------------------------------------------
# denver <- enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Denver County 1", district_name)) |>
#   select(end_year, district_name, n_students) |>
#   mutate(change = n_students - lag(n_students))
# 
# denver

## ----top-districts-chart------------------------------------------------------
# enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Denver County 1|Douglas County|Jefferson County|Cherry Creek", district_name)) |>
#   ggplot(aes(x = end_year, y = n_students, color = district_name)) +
#   geom_line(linewidth = 1.2) +
#   geom_point(size = 2) +
#   scale_y_continuous(labels = scales::comma) +
#   labs(
#     title = "Colorado's Largest Districts: Diverging Paths",
#     subtitle = "Denver declines while Douglas County grows",
#     x = "School Year",
#     y = "Enrollment",
#     color = "District"
#   )

## ----covid-k------------------------------------------------------------------
# covid_grades <- enr |>
#   filter(is_state, subgroup == "total_enrollment",
#          grade_level %in% c("K", "01", "05", "09"),
#          end_year %in% 2020:2024) |>
#   select(end_year, grade_level, n_students) |>
#   pivot_wider(names_from = grade_level, values_from = n_students)
# 
# covid_grades

## ----demographics-------------------------------------------------------------
# enr_2024 <- fetch_enr(2024, use_cache = TRUE)
# 
# demographics <- enr_2024 |>
#   filter(is_state, grade_level == "TOTAL",
#          subgroup %in% c("hispanic", "white", "black", "asian", "native_american", "multiracial")) |>
#   mutate(pct = round(pct * 100, 1)) |>
#   select(subgroup, n_students, pct) |>
#   arrange(desc(n_students))
# 
# demographics

## ----demographics-chart-------------------------------------------------------
# demographics |>
#   mutate(subgroup = forcats::fct_reorder(subgroup, n_students)) |>
#   ggplot(aes(x = n_students, y = subgroup, fill = subgroup)) +
#   geom_col(show.legend = FALSE) +
#   geom_text(aes(label = paste0(pct, "%")), hjust = -0.1) +
#   scale_x_continuous(labels = scales::comma, expand = expansion(mult = c(0, 0.15))) +
#   scale_fill_brewer(palette = "Set2") +
#   labs(
#     title = "Colorado Student Demographics (2024)",
#     subtitle = "Hispanic students are over a third of enrollment",
#     x = "Number of Students",
#     y = NULL
#   )

## ----douglas-county-----------------------------------------------------------
# denver_douglas <- enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Douglas County|Denver County", district_name)) |>
#   select(end_year, district_name, n_students) |>
#   pivot_wider(names_from = district_name, values_from = n_students)
# 
# denver_douglas

## ----western-slope------------------------------------------------------------
# western_slope <- enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Mesa County|Montrose|Delta", district_name)) |>
#   group_by(district_name) |>
#   summarize(
#     y2020 = n_students[end_year == 2020],
#     y2024 = n_students[end_year == 2024],
#     pct_change = round((y2024 / y2020 - 1) * 100, 1),
#     .groups = "drop"
#   ) |>
#   arrange(pct_change)
# 
# western_slope

## ----regional-chart-----------------------------------------------------------
# enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Mesa County Valley|Montrose County|Delta County", district_name)) |>
#   ggplot(aes(x = end_year, y = n_students, color = district_name)) +
#   geom_line(linewidth = 1.2) +
#   geom_point(size = 2) +
#   scale_y_continuous(labels = scales::comma) +
#   labs(
#     title = "Western Slope Districts: Declining Enrollment",
#     subtitle = "Rural districts losing students as housing costs rise",
#     x = "School Year",
#     y = "Enrollment",
#     color = "District"
#   )

## ----charters-----------------------------------------------------------------
# state_total <- enr_2024 |>
#   filter(is_state, subgroup == "total_enrollment", grade_level == "TOTAL") |>
#   pull(n_students)
# 
# charter_total <- enr_2024 |>
#   filter(is_charter, subgroup == "total_enrollment", grade_level == "TOTAL") |>
#   summarize(charter_total = sum(n_students, na.rm = TRUE)) |>
#   pull(charter_total)
# 
# tibble(
#   sector = c("All Public Schools", "Charter Schools"),
#   enrollment = c(state_total, charter_total),
#   pct = c(100, round(charter_total / state_total * 100, 1))
# )

## ----aurora-------------------------------------------------------------------
# aurora <- enr_2024 |>
#   filter(is_district, grade_level == "TOTAL",
#          grepl("Aurora", district_name),
#          subgroup %in% c("hispanic", "white", "black", "asian", "multiracial")) |>
#   mutate(pct = round(pct * 100, 1)) |>
#   select(district_name, subgroup, n_students, pct) |>
#   arrange(desc(pct))
# 
# aurora

## ----mountain-towns-----------------------------------------------------------
# mountain_towns <- enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Summit|Eagle County|Aspen|Vail", district_name, ignore.case = TRUE)) |>
#   group_by(district_name) |>
#   filter(n() > 5) |>
#   summarize(
#     earliest = n_students[end_year == min(end_year)],
#     latest = n_students[end_year == max(end_year)],
#     pct_change = round((latest / earliest - 1) * 100, 1),
#     .groups = "drop"
#   ) |>
#   arrange(pct_change)
# 
# mountain_towns

## ----northern-front-range-----------------------------------------------------
# northern <- enr |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL",
#          grepl("Poudre|Thompson|Weld|Greeley", district_name, ignore.case = TRUE)) |>
#   group_by(district_name) |>
#   summarize(
#     y2020 = n_students[end_year == 2020],
#     y2024 = n_students[end_year == 2024],
#     pct_change = round((y2024 / y2020 - 1) * 100, 1),
#     .groups = "drop"
#   ) |>
#   arrange(desc(pct_change))
# 
# northern

