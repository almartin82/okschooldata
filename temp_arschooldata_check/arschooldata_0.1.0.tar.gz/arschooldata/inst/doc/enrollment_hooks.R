## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE,
  fig.width = 8,
  fig.height = 5
)

## ----load-packages------------------------------------------------------------
library(arschooldata)
library(dplyr)

## ----available-years----------------------------------------------------------
get_available_years()

## ----fetch-one-year-----------------------------------------------------------
# Fetch 2024 enrollment data
data_2024 <- fetch_enr(2024, use_cache = TRUE)

# View the structure
head(data_2024)

## ----fetch-multi-year---------------------------------------------------------
# Fetch multiple years of data
data_multi <- fetch_enr_multi(2020:2024, use_cache = TRUE)

# View year counts
table(data_multi$end_year)

## ----view-ada-----------------------------------------------------------------
# View district names, IDs, and ADA
data_2024 %>%
  select(`1`, `2`, `2_ada`) %>%
  head(10)

## ----cache-status-------------------------------------------------------------
cache_status()

