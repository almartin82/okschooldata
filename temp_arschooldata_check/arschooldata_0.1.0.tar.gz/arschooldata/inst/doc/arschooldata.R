## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE,
  fig.width = 8,
  fig.height = 5
)

## ----install, eval=FALSE------------------------------------------------------
# # Install from GitHub
# devtools::install_github("almartin82/arschooldata")

## ----load---------------------------------------------------------------------
library(arschooldata)
library(dplyr)

## ----available-years----------------------------------------------------------
years <- get_available_years()
print(years$description)
cat("\nAvailable years:", paste(years$available_years, collapse = ", "))
cat("\nGap years (not available):", paste(years$gap_years, collapse = ", "))

## ----fetch-single, eval=FALSE-------------------------------------------------
# # Fetch 2024 data (2023-24 school year)
# data_2024 <- fetch_enr(2024)
# 
# # View dimensions
# dim(data_2024)
# 
# # View column names
# names(data_2024)[1:15]

## ----column-patterns, eval=FALSE----------------------------------------------
# # District name column
# name_col <- if ("1" %in% names(data)) "1"
#             else if ("district_name" %in% names(data)) "district_name"
#             else "actual_amount"  # 2013 format
# 
# # District ID column
# id_col <- if ("2" %in% names(data)) "2" else "district_lea"
# 
# # ADA column
# ada_col <- if ("2_ada" %in% names(data)) "2_ada" else "ada"

## ----fetch-multi, eval=FALSE--------------------------------------------------
# # Fetch 5 years of data
# data_multi <- fetch_enr_multi(2020:2024)
# 
# # Check years included
# table(data_multi$end_year)

## ----valid-data, eval=FALSE---------------------------------------------------
# # Get valid district rows (exclude headers and cooperatives if needed)
# id_col <- if ("2" %in% names(data)) "2" else "district_lea"
# 
# valid_districts <- data |>
#   filter(
#     !is.na(.data[[id_col]]),
#     grepl("^[0-9]+$", .data[[id_col]])
#   )
# 
# # Optionally exclude cooperatives (zero ADA entities)
# ada_col <- if ("2_ada" %in% names(data)) "2_ada" else "ada"
# active_districts <- valid_districts |>
#   filter(as.numeric(.data[[ada_col]]) > 0)

## ----example-analysis, eval=FALSE---------------------------------------------
# library(ggplot2)
# 
# # Get 2024 data
# data_2024 <- fetch_enr(2024)
# 
# # Filter to valid data rows and convert ADA to numeric
# clean_data <- data_2024 |>
#   filter(!is.na(`2`), grepl("^[0-9]", `2`)) |>
#   mutate(
#     district_name = `1`,
#     ada = as.numeric(`2_ada`)
#   )
# 
# # Top 10 districts by ADA
# top_10 <- clean_data |>
#   arrange(desc(ada)) |>
#   head(10)
# 
# print(top_10[, c("district_name", "ada")])
# 
# # Expected output (2023-24 data):
# # Springdale: ~20,313
# # Bentonville: ~17,929
# # Little Rock: ~17,582
# # Rogers: ~14,333
# # Fort Smith: ~12,404

## ----plot-top10, eval=FALSE---------------------------------------------------
# # Plot top 10 districts
# ggplot(top_10, aes(x = reorder(district_name, ada), y = ada)) +
#   geom_col(fill = "steelblue") +
#   coord_flip() +
#   labs(
#     title = "Top 10 Arkansas School Districts by ADA (2023-24)",
#     x = NULL,
#     y = "Average Daily Attendance"
#   ) +
#   theme_minimal()

## ----trend-analysis, eval=FALSE-----------------------------------------------
# # Get multi-year data
# data_multi <- fetch_enr_multi(c(2006, 2013:2024))
# 
# # Calculate state totals by year
# # Note: Must handle different column names across years
# calculate_state_ada <- function(data) {
#   id_col <- if ("2" %in% names(data)) "2" else "district_lea"
#   ada_col <- if ("2_ada" %in% names(data)) "2_ada" else "ada"
# 
#   valid <- data[!is.na(data[[id_col]]) & grepl("^[0-9]+$", data[[id_col]]), ]
#   sum(as.numeric(valid[[ada_col]]), na.rm = TRUE)
# }
# 
# state_totals <- data_multi |>
#   group_by(end_year) |>
#   summarize(
#     total_ada = sum(as.numeric(`2_ada`), na.rm = TRUE)
#   )
# 
# # Plot state total ADA over time
# ggplot(state_totals, aes(x = end_year, y = total_ada)) +
#   geom_line(color = "steelblue", linewidth = 1) +
#   geom_point(color = "steelblue", size = 3) +
#   scale_y_continuous(labels = scales::comma) +
#   labs(
#     title = "Arkansas Total K-12 Average Daily Attendance",
#     x = "School Year (End Year)",
#     y = "Total ADA"
#   ) +
#   theme_minimal()

## ----caching------------------------------------------------------------------
# Check cache status
cache_status()

## ----cache-management, eval=FALSE---------------------------------------------
# # Clear all cached data
# clear_cache()
# 
# # Clear only 2024 data
# clear_cache(2024)
# 
# # Force fresh download
# data_fresh <- fetch_enr(2024, use_cache = FALSE)

