# arschooldata

<!-- badges: start -->
[![R-CMD-check](https://github.com/almartin82/arschooldata/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/almartin82/arschooldata/actions/workflows/R-CMD-check.yaml)
[![Python Tests](https://github.com/almartin82/arschooldata/actions/workflows/python-test.yaml/badge.svg)](https://github.com/almartin82/arschooldata/actions/workflows/python-test.yaml)
[![pkgdown](https://github.com/almartin82/arschooldata/actions/workflows/pkgdown.yaml/badge.svg)](https://github.com/almartin82/arschooldata/actions/workflows/pkgdown.yaml)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

Fetch and analyze Arkansas school district fiscal and attendance data from the Arkansas Department of Education (ADE) in R or Python.

**[Documentation](https://almartin82.github.io/arschooldata/)** | **[Getting Started](https://almartin82.github.io/arschooldata/articles/arschooldata.html)**

## Installation

```r
# install.packages("remotes")
remotes::install_github("almartin82/arschooldata")
```

## Quick start

### R

```r
library(arschooldata)
library(dplyr)

# Check available years
get_available_years()

# Fetch one year
data_2024 <- fetch_enr(2024)

# Fetch multiple years
data_multi <- fetch_enr_multi(2020:2024)

# View district ADA (Average Daily Attendance)
data_2024 %>%
  select(`1`, `2`, `2_ada`) %>%
  head(10)
```

### Python

```python
import pyarschooldata as ar

# Check available years
years = ar.get_available_years()
print(f"Data available from {years['min_year']} to {years['max_year']}")

# Fetch one year
df = ar.fetch_enr(2024)

# Fetch multiple years
df_multi = ar.fetch_enr_multi([2020, 2021, 2022, 2023, 2024])

# View district data
print(df[['1', '2', '2_ada']].head(10))
```

## Data availability

| Years | Source | Notes |
|-------|--------|-------|
| **2006** | Annual Statistical Reports | Earliest available year |
| **2013-2024** | Annual Statistical Reports | Continuous coverage |
| **2007-2012** | - | Not available (missing ASR URLs) |

Data is sourced from the Arkansas Division of Elementary and Secondary Education (DESE) Annual Statistical Reports.

### What's included

- **District-level fiscal data:** Revenue, expenditures, millage rates, fund balances
- **Attendance data:** Average Daily Attendance (ADA), Average Daily Membership (ADM)
- **Financial breakdowns:** Instructional costs, administration, transportation, debt service
- **Staffing data:** FTE counts, salary information

### What's NOT included

- Enrollment demographics by race/ethnicity (available from ADE Data Center, not yet scraped)
- School-level data (district-level only)
- Grade-level enrollment breakdowns

### Arkansas ID system

- **District IDs:** 7 digits (e.g., 0401000 = Bentonville)

## Data source

Arkansas Division of Elementary and Secondary Education: [Annual Statistical Reports](https://dese.ade.arkansas.gov/offices/data-management/annual-statistical-report)

## Part of the State Schooldata Project

A simple, consistent interface for accessing state-published school data in Python and R.

**All 50 state packages:** [github.com/almartin82](https://github.com/almartin82?tab=repositories&q=schooldata)

## Author

[Andy Martin](https://github.com/almartin82) (almartin@gmail.com)

## License

MIT
