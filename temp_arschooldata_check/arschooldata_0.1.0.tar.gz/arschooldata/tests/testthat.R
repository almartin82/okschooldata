# This file is part of the standard testthat test harness.

library(testthat)
library(arschooldata)

test_check("arschooldata")
